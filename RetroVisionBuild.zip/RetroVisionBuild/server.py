#!/usr/bin/env python3
import http.server
import socketserver
import os
from urllib.parse import urlparse

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.getcwd(), **kwargs)
    
    def end_headers(self):
        # Disable caching for proper preview updates in Replit
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()
    
    def do_GET(self):
        # Handle SPA routing - serve index.html for all routes that don't match files
        url_path = urlparse(self.path).path
        file_path = url_path.lstrip('/')
        
        # If the path doesn't correspond to an existing file and it's not a root request,
        # serve index.html to handle React Router
        if file_path and not os.path.exists(file_path) and not file_path.startswith('assets/'):
            self.path = '/index.html'
        
        return super().do_GET()

def run_server():
    PORT = int(os.environ.get("PORT", 5000))
    HOST = "0.0.0.0"
    
    with socketserver.TCPServer((HOST, PORT), CustomHTTPRequestHandler) as httpd:
        print(f"Serving at http://{HOST}:{PORT}")
        print(f"Local access: http://localhost:{PORT}")
        print(f"Using PORT environment variable: {os.environ.get('PORT', 'not set, defaulting to 5000')}")
        httpd.serve_forever()

if __name__ == "__main__":
    run_server()