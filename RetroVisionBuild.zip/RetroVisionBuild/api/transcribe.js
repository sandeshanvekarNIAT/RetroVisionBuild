// Netlify Function for audio transcription
import { transcribeAudioWithFallback } from './lib/llm-providers/fallback.js';
import { checkRateLimit } from './lib/utils/rate-limit.js';
import { validateAudioFile } from './lib/utils/validation.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check rate limit
    const rateLimitCheck = checkRateLimit(event, 'transcribe');
    if (!rateLimitCheck.allowed) {
      return rateLimitCheck.response;
    }

    // Check content type
    const contentType = event.headers['content-type'] || '';
    if (!contentType.startsWith('multipart/form-data') && !contentType.startsWith('audio/')) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Content must be multipart/form-data or audio file' 
        })
      };
    }

    // For Netlify Functions, the body is base64 encoded for binary data
    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'No audio data provided' })
      };
    }

    let audioBuffer;
    let detectedContentType = contentType;

    try {
      // Decode base64 body to buffer
      audioBuffer = Buffer.from(event.body, 'base64');
      
      // If it's multipart, we need to extract the audio file
      if (contentType.startsWith('multipart/form-data')) {
        // For multipart data, we would need to parse it properly
        // For now, assume the audio data is provided directly
        // In a production app, you'd want proper multipart parsing
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ 
            error: 'Multipart form data parsing not implemented. Please send audio file directly.' 
          })
        };
      }

      // Detect audio format from content type or buffer
      if (contentType.includes('audio/')) {
        detectedContentType = contentType;
      } else {
        // Try to detect from buffer (basic detection)
        const bufferStart = audioBuffer.slice(0, 12);
        if (bufferStart.includes(Buffer.from('ID3'))) {
          detectedContentType = 'audio/mpeg';
        } else if (bufferStart.includes(Buffer.from('RIFF'))) {
          detectedContentType = 'audio/wav';
        } else if (bufferStart.includes(Buffer.from('OggS'))) {
          detectedContentType = 'audio/ogg';
        } else {
          detectedContentType = 'audio/mpeg'; // Default fallback
        }
      }

    } catch (error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid audio data format' 
        })
      };
    }

    // Validate file size (max 25MB for Whisper)
    const maxSize = 25 * 1024 * 1024; // 25MB
    if (audioBuffer.length > maxSize) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Audio file too large. Maximum size is 25MB.' 
        })
      };
    }

    console.log(`Starting transcription for audio file (${audioBuffer.length} bytes, ${detectedContentType})`);

    // Transcribe audio with fallback system
    const result = await transcribeAudioWithFallback(audioBuffer, detectedContentType);

    if (!result.success) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: 'Failed to transcribe audio',
          details: result.error
        })
      };
    }

    console.log(`Transcription completed using ${result.provider}: "${result.text.slice(0, 100)}..."`);

    return {
      statusCode: 200,
      headers: { ...headers, ...rateLimitCheck.headers },
      body: JSON.stringify({
        text: result.text,
        metadata: {
          provider: result.provider,
          model: result.model,
          audioSize: audioBuffer.length,
          contentType: detectedContentType,
          timestamp: new Date().toISOString()
        }
      })
    };

  } catch (error) {
    console.error('Transcription error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: 'Failed to transcribe audio'
      })
    };
  }
}