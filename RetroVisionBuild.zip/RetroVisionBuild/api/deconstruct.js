// Netlify Function for deconstructing inventions
import { callLLMWithFallback } from './lib/llm-providers/fallback.js';
import { DECONSTRUCT_SYSTEM_PROMPT, createDeconstructPrompt } from './lib/prompts/deconstruct.js';
import { getCachedDeconstruction, setCachedDeconstruction } from './lib/utils/cache.js';
import { checkRateLimit } from './lib/utils/rate-limit.js';
import { validateInvention } from './lib/utils/validation.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check rate limit
    const rateLimitCheck = checkRateLimit(event, 'deconstruct');
    if (!rateLimitCheck.allowed) {
      return rateLimitCheck.response;
    }

    // Parse request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    // Validate invention input
    const inventionValidation = validateInvention(body.invention);
    if (!inventionValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: inventionValidation.error })
      };
    }

    const invention = inventionValidation.sanitized;

    // Check cache first
    const cached = getCachedDeconstruction(invention);
    if (cached) {
      console.log(`Cache hit for deconstruction: ${invention}`);
      return {
        statusCode: 200,
        headers: { ...headers, ...rateLimitCheck.headers },
        body: JSON.stringify({
          decomposition: cached,
          cached: true,
          timestamp: new Date().toISOString()
        })
      };
    }

    console.log(`Starting deconstruction for: ${invention}`);

    // Call LLM with fallback system
    const systemPrompt = DECONSTRUCT_SYSTEM_PROMPT;
    const userPrompt = createDeconstructPrompt(invention);

    const result = await callLLMWithFallback(
      systemPrompt,
      userPrompt,
      0.2, // Low temperature for consistency
      2000  // Max tokens
    );

    // Parse the JSON response
    let decomposition;
    try {
      decomposition = JSON.parse(result.content);
    } catch (error) {
      console.error('Failed to parse LLM response as JSON:', error);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to process invention analysis',
          details: 'Invalid response format from AI'
        })
      };
    }

    // Cache the result
    setCachedDeconstruction(invention, decomposition);

    console.log(`Deconstruction completed for: ${invention} using ${result.provider}`);

    return {
      statusCode: 200,
      headers: { ...headers, ...rateLimitCheck.headers },
      body: JSON.stringify({
        decomposition,
        metadata: {
          provider: result.provider,
          model: result.model,
          cached: false,
          timestamp: new Date().toISOString()
        }
      })
    };

  } catch (error) {
    console.error('Deconstruction error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: 'Failed to process invention analysis'
      })
    };
  }
}