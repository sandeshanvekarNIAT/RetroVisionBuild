// Netlify Function for exporting PPTX and PDF files
import { generatePPTX, generatePDF } from './lib/utils/export.js';
import { checkRateLimit } from './lib/utils/rate-limit.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check rate limit
    const rateLimitCheck = checkRateLimit(event, 'export');
    if (!rateLimitCheck.allowed) {
      return rateLimitCheck.response;
    }

    // Parse request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (error) {
      return {
        statusCode: 400,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    const { 
      format, // 'pptx' or 'pdf'
      data    // The complete report data
    } = body;

    // Validate required fields
    if (!format || !['pptx', 'pdf'].includes(format)) {
      return {
        statusCode: 400,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          error: 'Format must be either "pptx" or "pdf"' 
        })
      };
    }

    if (!data || !data.invention) {
      return {
        statusCode: 400,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          error: 'Report data is required with at least invention name' 
        })
      };
    }

    console.log(`Starting ${format.toUpperCase()} export for: ${data.invention}`);

    let exportResult;
    let contentType;
    let filename;

    if (format === 'pptx') {
      // Generate PPTX
      const pptx = await generatePPTX(data);
      const pptxBuffer = await pptx.write({ outputType: 'nodebuffer' });
      
      exportResult = pptxBuffer.toString('base64');
      contentType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
      filename = `${data.invention.replace(/[^a-zA-Z0-9]/g, '_')}_${data.era?.replace(/[^a-zA-Z0-9]/g, '_') || 'analysis'}.pptx`;
      
    } else if (format === 'pdf') {
      // Generate PDF
      const pdfBuffer = await generatePDF(data);
      
      exportResult = pdfBuffer.toString('base64');
      contentType = 'application/pdf';
      filename = `${data.invention.replace(/[^a-zA-Z0-9]/g, '_')}_${data.era?.replace(/[^a-zA-Z0-9]/g, '_') || 'analysis'}.pdf`;
    }

    console.log(`${format.toUpperCase()} export completed for: ${data.invention}`);

    // Return the file as base64 with proper headers
    return {
      statusCode: 200,
      headers: {
        ...headers,
        ...rateLimitCheck.headers,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        format,
        filename,
        data: exportResult, // Base64 encoded file
        contentType,
        size: exportResult.length,
        metadata: {
          invention: data.invention,
          era: data.era,
          timestamp: new Date().toISOString()
        }
      })
    };

  } catch (error) {
    console.error('Export error:', error);
    
    return {
      statusCode: 500,
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Internal server error',
        message: 'Failed to generate export file',
        details: error.message
      })
    };
  }
}