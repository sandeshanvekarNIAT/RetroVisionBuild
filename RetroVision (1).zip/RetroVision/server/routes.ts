import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { callHFText } from "./services/huggingface";
import { deconstructPrompt } from "./services/prompts";
import { deconstructRequestSchema, type DeconstructResponse } from "@shared/schema";
import { log } from "./vite";
import fs from "fs";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // Main deconstruction endpoint
  app.post("/api/deconstruct", async (req, res) => {
    try {
      const { invention, era } = deconstructRequestSchema.parse(req.body);
      
      // Check for mock mode
      const mockMode = req.query.mock === "true";
      
      if (mockMode) {
        try {
          const samplePath = path.resolve(import.meta.dirname, "sample_outputs", "smartphone.json");
          const sampleData = JSON.parse(fs.readFileSync(samplePath, "utf-8"));
          
          const response: DeconstructResponse = {
            decomposition: sampleData,
            cached: false,
            timestamp: new Date().toISOString(),
          };
          
          return res.json(response);
        } catch (error) {
          log(`Mock mode failed: ${error}`, "api");
          return res.status(500).json({ error: "Mock data not available" });
        }
      }

      // Create cache key
      const cacheKey = `${invention.toLowerCase()}${era ? `_${era.toLowerCase()}` : ""}`;
      
      // Check cache first
      const cached = await storage.getCachedDeconstruction(cacheKey);
      if (cached) {
        log(`Cache hit for: ${cacheKey}`, "api");
        const response: DeconstructResponse = {
          decomposition: cached,
          cached: true,
          timestamp: new Date().toISOString(),
        };
        return res.json(response);
      }

      // Generate prompt and call HF API
      const prompt = deconstructPrompt(invention, era);
      const model = "mistralai/Mistral-7B-Instruct-v0.2";
      
      log(`Calling HF API for: ${invention}${era ? ` (${era})` : ""}`, "api");
      
      const rawResponse = await callHFText(model, prompt, 0.2, 800);
      
      // Clean and parse JSON response
      let cleanedResponse = rawResponse.trim();
      
      // Try to extract JSON if there's extra text
      const jsonMatch = cleanedResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        cleanedResponse = jsonMatch[0];
      }
      
      // Parse the JSON
      const decomposition = JSON.parse(cleanedResponse);
      
      // Validate the structure
      if (!decomposition.name || !Array.isArray(decomposition.core_functions)) {
        throw new Error("Invalid JSON structure from AI model");
      }
      
      // Cache the result
      await storage.cacheDeconstruction(cacheKey, decomposition);
      
      const response: DeconstructResponse = {
        decomposition,
        cached: false,
        timestamp: new Date().toISOString(),
      };
      
      res.json(response);
      
    } catch (error) {
      log(`Deconstruction error: ${error}`, "api");
      
      if (error instanceof SyntaxError) {
        return res.status(500).json({ 
          error: "Failed to parse AI response as valid JSON",
          details: "The AI model returned malformed JSON. Please try again."
        });
      }
      
      if (error instanceof Error) {
        return res.status(500).json({ 
          error: "Failed to generate deconstruction",
          details: error.message
        });
      }
      
      res.status(500).json({ 
        error: "Internal server error",
        details: "An unexpected error occurred while processing your request."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
