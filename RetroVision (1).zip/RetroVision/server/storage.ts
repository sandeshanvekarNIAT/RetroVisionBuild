import { type Deconstruction } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  cacheDeconstruction(key: string, result: Deconstruction): Promise<void>;
  getCachedDeconstruction(key: string): Promise<Deconstruction | undefined>;
}

export class MemStorage implements IStorage {
  private cache: Map<string, { result: Deconstruction; timestamp: Date }>;

  constructor() {
    this.cache = new Map();
  }

  async cacheDeconstruction(key: string, result: Deconstruction): Promise<void> {
    this.cache.set(key, { result, timestamp: new Date() });
  }

  async getCachedDeconstruction(key: string): Promise<Deconstruction | undefined> {
    const cached = this.cache.get(key);
    if (cached) {
      // Cache expires after 1 hour
      const isExpired = Date.now() - cached.timestamp.getTime() > 60 * 60 * 1000;
      if (!isExpired) {
        return cached.result;
      } else {
        this.cache.delete(key);
      }
    }
    return undefined;
  }
}

export const storage = new MemStorage();
