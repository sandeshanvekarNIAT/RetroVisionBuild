export function deconstructPrompt(invention: string, era?: string): string {
  const eraContext = era ? ` reimagined for the ${era} era` : "";
  
  return `You are an expert historian-engineer analyzing inventions across time periods.

Deconstruct the invention "${invention}"${eraContext} into a valid JSON object with EXACTLY these keys:
{
  "name": string,
  "core_functions": [strings],
  "materials": [strings], 
  "enabling_sciences": [strings],
  "subsystems": [{ "name": string, "dependencies": [strings] }],
  "cultural_drivers": [strings],
  "min_tech_level": [{ "tech": string, "note": string }]
}

Rules:
- Return ONLY valid JSON, no commentary or explanation
- Focus on fundamental components and requirements
- Consider what would be technically feasible in the specified era
- Be specific and detailed in your analysis
- Ensure all arrays contain meaningful entries

JSON:`;
}
