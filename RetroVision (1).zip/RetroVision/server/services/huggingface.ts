import { log } from "../vite";

const HF_TOKEN = process.env.HF_API_KEY || process.env.HUGGING_FACE_API_KEY;
const HF_API_BASE = "https://api-inference.huggingface.co/models";

export async function callHFText(
  model: string,
  prompt: string,
  temperature = 0.2,
  maxTokens = 600
): Promise<string> {
  if (!HF_TOKEN) {
    throw new Error("Hugging Face API token not configured");
  }

  try {
    const response = await fetch(`${HF_API_BASE}/${model}`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${HF_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          temperature,
          max_new_tokens: maxTokens,
          return_full_text: false,
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      log(`HF API Error: ${response.status} - ${error}`, "huggingface");
      throw new Error(`Hugging Face API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (Array.isArray(data) && data[0]?.generated_text) {
      return data[0].generated_text;
    }
    
    if (data.generated_text) {
      return data.generated_text;
    }
    
    log(`Unexpected HF response format: ${JSON.stringify(data)}`, "huggingface");
    throw new Error("Unexpected response format from Hugging Face API");
    
  } catch (error) {
    log(`HF API call failed: ${error}`, "huggingface");
    throw error;
  }
}
