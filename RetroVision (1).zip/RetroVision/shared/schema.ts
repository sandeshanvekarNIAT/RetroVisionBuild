import { z } from "zod";

// Deconstruction result schema
export const subsystemSchema = z.object({
  name: z.string(),
  dependencies: z.array(z.string()),
});

export const minTechLevelSchema = z.object({
  tech: z.string(),
  note: z.string(),
});

export const deconstructionSchema = z.object({
  name: z.string(),
  core_functions: z.array(z.string()),
  materials: z.array(z.string()),
  enabling_sciences: z.array(z.string()),
  subsystems: z.array(subsystemSchema),
  cultural_drivers: z.array(z.string()),
  min_tech_level: z.array(minTechLevelSchema),
});

export const deconstructRequestSchema = z.object({
  invention: z.string().min(1, "Invention name is required"),
  era: z.string().optional(),
});

export const deconstructResponseSchema = z.object({
  decomposition: deconstructionSchema,
  cached: z.boolean().optional(),
  timestamp: z.string().optional(),
});

export type Subsystem = z.infer<typeof subsystemSchema>;
export type MinTechLevel = z.infer<typeof minTechLevelSchema>;
export type Deconstruction = z.infer<typeof deconstructionSchema>;
export type DeconstructRequest = z.infer<typeof deconstructRequestSchema>;
export type DeconstructResponse = z.infer<typeof deconstructResponseSchema>;
