# Retro-Vision AI - Phase 1

## Overview

Retro-Vision AI is an AI-powered web application that reimagines modern inventions in earlier historical timelines. The project decomposes inventions into their fundamental components and explores how they could have been created with period-appropriate technology. This is Phase 1 of a multi-phase project focused on text-based invention deconstruction, with future phases planned for image generation, voice input, and story/export features.

The application takes user input in the form of "invention + era" (e.g., "Smartphone + 1800s") and returns a detailed JSON breakdown of the invention's core functions, materials, enabling sciences, subsystems, cultural drivers, and minimum technology requirements.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built as a React Single Page Application (SPA) using modern tooling:
- **React 18** with TypeScript for type safety and developer experience
- **Vite** as the build tool and development server for fast hot-reload
- **Tailwind CSS** with shadcn/ui components for consistent, accessible UI design
- **TanStack Query** for client-side state management and API caching
- **Wouter** as a lightweight router for navigation

The component structure follows a modular approach with reusable UI components from shadcn/ui and custom components for invention forms and results display. The application uses a card-based layout with collapsible sections for organizing the deconstruction results.

### Backend Architecture
The backend is a Node.js Express server with the following design decisions:
- **Express.js** framework for HTTP server and middleware
- **TypeScript** throughout for type consistency between frontend and backend
- **In-memory caching** via a simple Map-based storage system for performance
- **Modular service architecture** with separate services for AI integration and prompt engineering
- **Shared schema validation** using Zod for type-safe communication between client and server

The server implements RESTful API endpoints with proper error handling and request logging. It supports a mock mode for development and testing without requiring external AI services.

### Data Storage Solutions
Currently uses in-memory storage for caching API responses:
- **MemStorage class** implements a simple key-value cache with TTL (1-hour expiration)
- **Cache keys** generated from invention name and era for efficient lookup
- **Future-ready** architecture with IStorage interface for easy migration to persistent storage

### Authentication and Authorization
Phase 1 does not implement authentication. The application is designed as a public tool with no user accounts or sensitive data requiring protection. Future phases may add user management if needed for advanced features.

### External Service Integrations
The application is designed to integrate with AI text generation services:
- **Hugging Face Inference API** integration for text generation using various language models
- **Configurable model selection** through environment variables
- **Fallback mock mode** for development and testing scenarios
- **Structured prompt engineering** with dedicated service for generating AI prompts

The AI integration uses a service-oriented approach, making it easy to swap between different providers or models as needed.

## External Dependencies

### Core Framework Dependencies
- **React ecosystem**: React 18, React DOM, TypeScript
- **Build tools**: Vite, esbuild for production builds
- **Styling**: Tailwind CSS, PostCSS, Autoprefixer
- **UI Components**: Comprehensive shadcn/ui component library built on Radix UI primitives

### State Management and Data Fetching
- **@tanstack/react-query**: Client-side state management and API caching
- **axios**: HTTP client for API communication
- **wouter**: Lightweight client-side routing

### Backend Dependencies
- **Express.js**: Web framework for Node.js
- **cors**: Cross-origin resource sharing middleware
- **tsx**: TypeScript execution for development

### Database and Schema
- **Drizzle ORM**: Type-safe database toolkit (configured for future PostgreSQL integration)
- **@neondatabase/serverless**: Serverless PostgreSQL driver (prepared for future use)
- **Zod**: Schema validation and type inference for shared types

### AI and External APIs
- **Hugging Face Inference API**: Text generation and AI model access
- **Custom prompt engineering**: Structured prompts for consistent AI responses

### Development and Quality Tools
- **TypeScript**: Static type checking across the entire stack
- **ESLint configuration**: Code quality and consistency
- **Replit-specific plugins**: Development environment integration and error handling

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Conditional CSS class handling
- **lucide-react**: Icon library for consistent UI elements
- **class-variance-authority**: Type-safe CSS variant management