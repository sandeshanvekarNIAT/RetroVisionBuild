import { apiRequest } from "./queryClient";
import type { DeconstructRequest, DeconstructResponse } from "@shared/schema";

export async function deconstructInvention(
  data: DeconstructRequest,
  mockMode = false
): Promise<DeconstructResponse> {
  const url = mockMode ? "/api/deconstruct?mock=true" : "/api/deconstruct";
  const response = await apiRequest("POST", url, data);
  return response.json();
}

export async function checkApiHealth(): Promise<{ status: string; timestamp: string }> {
  const response = await apiRequest("GET", "/api/health");
  return response.json();
}
