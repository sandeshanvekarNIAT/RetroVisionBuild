import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import InventionForm from "../components/invention-form";
import ResultsDisplay from "../components/results-display";
import { checkApiHealth } from "../lib/api";
import { Settings, Server, Database } from "lucide-react";
import type { DeconstructResponse } from "@shared/schema";

export default function Home() {
  const [result, setResult] = useState<DeconstructResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { data: healthStatus } = useQuery({
    queryKey: ["/api/health"],
    queryFn: checkApiHealth,
    refetchInterval: 30000, // Check every 30 seconds
  });

  const handleResult = (newResult: DeconstructResponse) => {
    setResult(newResult);
    setIsLoading(false);
  };

  const handleReanalyze = () => {
    setResult(null);
  };

  return (
    <div className="min-h-screen retro-gradient">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Settings className="text-primary-foreground" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Retro-Vision AI</h1>
                <p className="text-sm text-muted-foreground">Invention Deconstruction Engine</p>
              </div>
            </div>
            <div className="ml-auto">
              <span className="px-3 py-1 text-xs font-medium bg-accent text-accent-foreground rounded-full">
                Phase 1 - MVP
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <InventionForm onResult={handleResult} />

          {/* Results Section */}
          <ResultsDisplay 
            isLoading={isLoading}
            result={result}
            onReanalyze={handleReanalyze}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-16">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Retro-Vision AI &copy; 2024 - Phase 1 MVP
            </div>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
              <span className="flex items-center">
                <Server className="mr-1" size={14} />
                API Status: <span className={`ml-1 ${healthStatus ? 'text-accent' : 'text-destructive'}`}>
                  {healthStatus ? 'Active' : 'Offline'}
                </span>
              </span>
              <span className="flex items-center">
                <Database className="mr-1" size={14} />
                Cache: <span className="text-accent ml-1">Enabled</span>
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
