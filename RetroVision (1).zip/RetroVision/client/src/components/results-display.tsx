import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import CollapsibleSection from "./collapsible-section";
import { 
  Smartphone, 
  List, 
  Box, 
  FlaskConical, 
  Table, 
  Users, 
  Layers, 
  Download, 
  Share, 
  RotateCcw,
  Loader2
} from "lucide-react";
import type { DeconstructResponse } from "@shared/schema";

interface ResultsDisplayProps {
  isLoading: boolean;
  result: DeconstructResponse | null;
  onReanalyze: () => void;
}

export default function ResultsDisplay({ isLoading, result, onReanalyze }: ResultsDisplayProps) {
  if (isLoading) {
    return (
      <Card className="p-8 text-center">
        <Loader2 className="animate-spin w-8 h-8 mx-auto mb-4 text-primary" />
        <p className="text-muted-foreground">Deconstructing invention...</p>
      </Card>
    );
  }

  if (!result) {
    return (
      <Card className="p-12 text-center">
        <i className="fas fa-lightbulb text-6xl text-muted-foreground mb-4 opacity-50"></i>
        <h3 className="text-lg font-semibold text-foreground mb-2">Ready to Deconstruct</h3>
        <p className="text-muted-foreground mb-6">Enter an invention and era to see its detailed breakdown</p>
        <Button onClick={onReanalyze} data-testid="button-sample">
          Try Sample: Smartphone + 1800s
        </Button>
      </Card>
    );
  }

  const { decomposition, cached } = result;

  const handleExport = () => {
    const dataStr = JSON.stringify(decomposition, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${decomposition.name.toLowerCase().replace(/\s+/g, '-')}-deconstruction.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Retro-Vision AI: ${decomposition.name}`,
          text: `Check out this AI deconstruction of ${decomposition.name}!`,
          url: window.location.href,
        });
      } catch (error) {
        // Fallback to clipboard
        navigator.clipboard.writeText(window.location.href);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="space-y-4" data-testid="results-display">
      {/* Header Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Smartphone className="text-accent" size={24} />
              <h2 className="text-xl font-semibold text-foreground" data-testid="text-invention-name">
                {decomposition.name}
              </h2>
            </div>
            <div className="flex items-center space-x-2">
              {cached && (
                <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-700 rounded-full">
                  Cached
                </span>
              )}
              <span className="px-3 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-full">
                Analysis Complete
              </span>
            </div>
          </div>
          <p className="text-muted-foreground">
            Comprehensive deconstruction showing core functions, required materials, enabling sciences, and cultural drivers.
          </p>
        </CardContent>
      </Card>

      {/* Core Functions */}
      <CollapsibleSection
        title="Core Functions"
        icon={<List className="text-primary" size={20} />}
        count={decomposition.core_functions.length}
        countColor="primary"
        defaultOpen={true}
      >
        <div className="grid grid-cols-2 gap-3">
          {decomposition.core_functions.map((func, index) => (
            <div key={index} className="p-3 bg-muted/30 rounded-lg">
              <i className="fas fa-cog text-primary text-sm mr-2"></i>
              <span className="text-sm font-medium capitalize">{func}</span>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Materials */}
      <CollapsibleSection
        title="Required Materials"
        icon={<Box className="text-accent" size={20} />}
        count={decomposition.materials.length}
        countColor="accent"
      >
        <div className="space-y-3">
          {decomposition.materials.map((material, index) => (
            <div key={index} className="flex items-center p-3 border border-border rounded-lg">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                <i className="fas fa-cube text-blue-600 text-sm"></i>
              </div>
              <div>
                <span className="font-medium text-foreground capitalize">{material}</span>
                <p className="text-xs text-muted-foreground">Essential material component</p>
              </div>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Enabling Sciences */}
      <CollapsibleSection
        title="Enabling Sciences"
        icon={<FlaskConical className="text-purple-500" size={20} />}
        count={decomposition.enabling_sciences.length}
        countColor="purple"
      >
        <div className="space-y-3">
          {decomposition.enabling_sciences.map((science, index) => (
            <div key={index} className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
              <h4 className="font-medium text-foreground mb-1 capitalize">{science}</h4>
              <p className="text-sm text-muted-foreground">Critical scientific understanding required</p>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Subsystems */}
      {decomposition.subsystems && decomposition.subsystems.length > 0 && (
        <CollapsibleSection
          title="Subsystems"
          icon={<Table className="text-orange-500" size={20} />}
          count={decomposition.subsystems.length}
          countColor="orange"
        >
          <div className="space-y-4">
            {decomposition.subsystems.map((subsystem, index) => (
              <div key={index} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-foreground capitalize">{subsystem.name}</h4>
                  <i className="fas fa-sitemap text-orange-500"></i>
                </div>
                <div className="flex flex-wrap gap-2">
                  {subsystem.dependencies.map((dep, depIndex) => (
                    <span
                      key={depIndex}
                      className="px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded capitalize"
                    >
                      {dep}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CollapsibleSection>
      )}

      {/* Cultural Drivers */}
      <CollapsibleSection
        title="Cultural Drivers"
        icon={<Users className="text-indigo-500" size={20} />}
        count={decomposition.cultural_drivers.length}
        countColor="indigo"
      >
        <div className="space-y-3">
          {decomposition.cultural_drivers.map((driver, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-indigo-50 rounded-lg">
              <i className="fas fa-users text-indigo-500 mt-1"></i>
              <div>
                <h4 className="font-medium text-foreground capitalize">{driver}</h4>
                <p className="text-sm text-muted-foreground mt-1">Social or cultural motivation</p>
              </div>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Minimum Tech Level */}
      <CollapsibleSection
        title="Minimum Tech Level"
        icon={<Layers className="text-red-500" size={20} />}
        count={decomposition.min_tech_level.length}
        countColor="red"
      >
        <div className="space-y-3">
          {decomposition.min_tech_level.map((tech, index) => (
            <div key={index} className="border-l-4 border-red-400 bg-red-50 p-4 rounded-r-lg">
              <h4 className="font-medium text-foreground mb-1 capitalize">{tech.tech}</h4>
              <p className="text-sm text-red-700">{tech.note}</p>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Action Buttons */}
      <div className="flex space-x-3 pt-4">
        <Button onClick={handleExport} className="flex-1" data-testid="button-export">
          <Download className="mr-2" size={16} />
          Export JSON
        </Button>
        <Button variant="outline" onClick={handleShare} data-testid="button-share">
          <Share className="mr-2" size={16} />
          Share
        </Button>
        <Button variant="outline" onClick={onReanalyze} data-testid="button-reanalyze">
          <RotateCcw className="mr-2" size={16} />
          Reanalyze
        </Button>
      </div>
    </div>
  );
}
