import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface CollapsibleSectionProps {
  title: string;
  icon: React.ReactNode;
  count?: number;
  countColor?: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export default function CollapsibleSection({
  title,
  icon,
  count,
  countColor = "primary",
  children,
  defaultOpen = false,
}: CollapsibleSectionProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const getCountClasses = (color: string) => {
    const colorMap: Record<string, string> = {
      primary: "bg-primary/10 text-primary",
      accent: "bg-accent/10 text-accent",
      purple: "bg-purple-100 text-purple-600",
      orange: "bg-orange-100 text-orange-600",
      indigo: "bg-indigo-100 text-indigo-600",
      red: "bg-red-100 text-red-600",
    };
    return colorMap[color] || colorMap.primary;
  };

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm">
      <button
        className="w-full p-6 text-left focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 rounded-xl"
        onClick={() => setIsOpen(!isOpen)}
        data-testid={`button-toggle-${title.toLowerCase().replace(/\s+/g, '-')}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {icon}
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            {count !== undefined && (
              <span className={`px-2 py-1 text-xs rounded-full ${getCountClasses(countColor)}`}>
                {count}
              </span>
            )}
          </div>
          <ChevronDown
            className={`text-muted-foreground transform transition-transform ${
              isOpen ? "rotate-180" : ""
            }`}
            size={20}
          />
        </div>
      </button>
      {isOpen && (
        <div className="px-6 pb-6" data-testid={`content-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {children}
        </div>
      )}
    </div>
  );
}
