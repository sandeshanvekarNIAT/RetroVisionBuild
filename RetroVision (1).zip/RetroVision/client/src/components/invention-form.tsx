import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deconstructInvention } from "../lib/api";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader } from "./ui/card";
import { useToast } from "../hooks/use-toast";
import { Lightbulb, Wand2, FlaskConical } from "lucide-react";

interface InventionFormProps {
  onResult: (result: any) => void;
}

export default function InventionForm({ onResult }: InventionFormProps) {
  const [invention, setInvention] = useState("");
  const [era, setEra] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deconstructMutation = useMutation({
    mutationFn: ({ invention, era, mockMode }: { invention: string; era: string; mockMode?: boolean }) =>
      deconstructInvention({ invention, era }, mockMode),
    onSuccess: (data) => {
      onResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/deconstruct"] });
      toast({
        title: "Success!",
        description: `Successfully deconstructed "${invention}"`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to deconstruct invention",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invention.trim()) {
      toast({
        title: "Error",
        description: "Please enter an invention name",
        variant: "destructive",
      });
      return;
    }
    deconstructMutation.mutate({ invention, era });
  };

  const handleMockMode = () => {
    deconstructMutation.mutate({ invention: "Smartphone", era: "1800s", mockMode: true });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-2">
            <Lightbulb className="text-accent" size={20} />
            <h2 className="text-xl font-semibold text-foreground">Deconstruct Invention</h2>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="invention" className="text-sm font-medium text-foreground mb-2">
                Invention Name
              </Label>
              <Input
                id="invention"
                type="text"
                placeholder="e.g., Smartphone, Steam Engine, Television..."
                value={invention}
                onChange={(e) => setInvention(e.target.value)}
                className="mt-2"
                data-testid="input-invention"
              />
            </div>
            
            <div>
              <Label htmlFor="era" className="text-sm font-medium text-foreground mb-2">
                Target Era
              </Label>
              <Input
                id="era"
                type="text"
                placeholder="e.g., 1800s, Medieval, Ancient Rome..."
                value={era}
                onChange={(e) => setEra(e.target.value)}
                className="mt-2"
                data-testid="input-era"
              />
            </div>
            
            <div className="flex space-x-3 pt-2">
              <Button
                type="submit"
                className="flex-1"
                disabled={deconstructMutation.isPending}
                data-testid="button-deconstruct"
              >
                <Wand2 className="mr-2" size={16} />
                {deconstructMutation.isPending ? "Deconstructing..." : "Deconstruct"}
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={handleMockMode}
                disabled={deconstructMutation.isPending}
                title="Demo with sample data"
                data-testid="button-mock"
              >
                <FlaskConical size={16} />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      {/* How it Works */}
      <Card>
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">How It Works</h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary text-xs font-semibold">1</span>
              </div>
              <p>Enter any invention and target historical era</p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary text-xs font-semibold">2</span>
              </div>
              <p>AI analyzes the invention's core components and requirements</p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-primary text-xs font-semibold">3</span>
              </div>
              <p>Get detailed breakdown of materials, sciences, and cultural context</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
