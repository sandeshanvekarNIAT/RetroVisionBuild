// Netlify Function for simulating alternate invention pathways
import { callLLMWithFallback } from './lib/llm-providers/fallback.js';
import { SIMULATE_SYSTEM_PROMPT, createSimulatePrompt } from './lib/prompts/simulate.js';
import { getCachedSimulation, setCachedSimulation } from './lib/utils/cache.js';
import { checkRateLimit } from './lib/utils/rate-limit.js';
import { validateInvention, validateEra, validateCreativity, validateDepth } from './lib/utils/validation.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check rate limit
    const rateLimitCheck = checkRateLimit(event, 'simulate');
    if (!rateLimitCheck.allowed) {
      return rateLimitCheck.response;
    }

    // Parse request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    // Validate inputs
    const inventionValidation = validateInvention(body.invention);
    if (!inventionValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: inventionValidation.error })
      };
    }

    const eraValidation = validateEra(body.era);
    if (!eraValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: eraValidation.error })
      };
    }

    const creativityValidation = validateCreativity(body.creativity);
    if (!creativityValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: creativityValidation.error })
      };
    }

    const depthValidation = validateDepth(body.depth);
    if (!depthValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: depthValidation.error })
      };
    }

    const invention = inventionValidation.sanitized;
    const era = eraValidation.sanitized;
    const creativity = creativityValidation.sanitized;
    const depth = depthValidation.sanitized;

    // Decomposition is required - either provided or fetch from cache/previous request
    const decomposition = body.decomposition;
    if (!decomposition) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Decomposition data is required. Please run deconstruction first.' 
        })
      };
    }

    // Check cache first
    const cached = getCachedSimulation(invention, era, creativity);
    if (cached) {
      console.log(`Cache hit for simulation: ${invention} in ${era}`);
      return {
        statusCode: 200,
        headers: { ...headers, ...rateLimitCheck.headers },
        body: JSON.stringify({
          simulations: cached,
          cached: true,
          timestamp: new Date().toISOString()
        })
      };
    }

    console.log(`Starting simulation for: ${invention} in ${era} (creativity: ${creativity}, depth: ${depth})`);

    // Call LLM with fallback system
    const systemPrompt = SIMULATE_SYSTEM_PROMPT;
    const userPrompt = createSimulatePrompt(invention, era, decomposition, creativity, depth);

    const result = await callLLMWithFallback(
      systemPrompt,
      userPrompt,
      creativity, // Use user-specified creativity as temperature
      3000  // Max tokens for detailed pathways
    );

    // Parse the JSON response
    let simulations;
    try {
      simulations = JSON.parse(result.content);
    } catch (error) {
      console.error('Failed to parse LLM response as JSON:', error);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to process simulation',
          details: 'Invalid response format from AI'
        })
      };
    }

    // Cache the result
    setCachedSimulation(invention, era, creativity, simulations);

    console.log(`Simulation completed for: ${invention} in ${era} using ${result.provider}`);

    return {
      statusCode: 200,
      headers: { ...headers, ...rateLimitCheck.headers },
      body: JSON.stringify({
        simulations,
        metadata: {
          provider: result.provider,
          model: result.model,
          creativity,
          depth,
          cached: false,
          timestamp: new Date().toISOString()
        }
      })
    };

  } catch (error) {
    console.error('Simulation error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: 'Failed to process simulation'
      })
    };
  }
}