// Netlify Function for generating images with AI
import { generateImageWithFallback } from './lib/llm-providers/fallback.js';
import { createVisualPrompt, createSchematicPrompt, createPrototypePrompt } from './lib/prompts/visual.js';
import { getCachedImage, setCachedImage } from './lib/utils/cache.js';
import { checkRateLimit } from './lib/utils/rate-limit.js';
import { validateImagePrompt } from './lib/utils/validation.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check rate limit
    const rateLimitCheck = checkRateLimit(event, 'image');
    if (!rateLimitCheck.allowed) {
      return rateLimitCheck.response;
    }

    // Parse request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    // Extract and validate parameters
    const { 
      invention, 
      era, 
      pathwayDescription, 
      technicalDetails,
      prototypeDescription,
      style = "technical blueprint", 
      size = "1024x1024",
      imageType = "blueprint" // blueprint, schematic, prototype
    } = body;

    // Validate required fields based on image type
    if (!invention || !era) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Invention and era are required fields' 
        })
      };
    }

    // Generate appropriate prompt based on image type
    let finalPrompt;
    switch (imageType) {
      case 'schematic':
        if (!technicalDetails) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ 
              error: 'Technical details are required for schematic images' 
            })
          };
        }
        finalPrompt = createSchematicPrompt(invention, era, technicalDetails);
        break;
        
      case 'prototype':
        if (!prototypeDescription) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ 
              error: 'Prototype description is required for prototype images' 
            })
          };
        }
        finalPrompt = createPrototypePrompt(invention, era, prototypeDescription);
        break;
        
      case 'blueprint':
      default:
        if (!pathwayDescription) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ 
              error: 'Pathway description is required for blueprint images' 
            })
          };
        }
        finalPrompt = createVisualPrompt(invention, era, pathwayDescription, style);
        break;
    }

    // Validate the final prompt
    const promptValidation = validateImagePrompt(finalPrompt);
    if (!promptValidation.valid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: promptValidation.error })
      };
    }

    const sanitizedPrompt = promptValidation.sanitized;

    // Check cache first
    const cached = getCachedImage(sanitizedPrompt);
    if (cached) {
      console.log(`Cache hit for image generation`);
      return {
        statusCode: 200,
        headers: { ...headers, ...rateLimitCheck.headers },
        body: JSON.stringify({
          ...cached,
          cached: true,
          timestamp: new Date().toISOString()
        })
      };
    }

    console.log(`Starting image generation for: ${invention} in ${era} (${imageType})`);

    // Generate image with fallback system
    const result = await generateImageWithFallback(
      sanitizedPrompt,
      size,
      style === "artistic" ? "vivid" : "natural"
    );

    if (!result.success) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: 'Failed to generate image',
          details: result.error
        })
      };
    }

    // Prepare response data
    const imageData = {
      url: result.url,
      prompt: sanitizedPrompt,
      invention,
      era,
      imageType,
      style,
      size,
      provider: result.provider,
      model: result.model
    };

    // Cache the result
    setCachedImage(sanitizedPrompt, imageData);

    console.log(`Image generation completed using ${result.provider}`);

    return {
      statusCode: 200,
      headers: { ...headers, ...rateLimitCheck.headers },
      body: JSON.stringify({
        image: imageData,
        metadata: {
          provider: result.provider,
          model: result.model,
          cached: false,
          timestamp: new Date().toISOString()
        }
      })
    };

  } catch (error) {
    console.error('Image generation error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: 'Failed to generate image'
      })
    };
  }
}