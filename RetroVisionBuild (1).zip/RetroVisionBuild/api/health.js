// Netlify Function for health checks
import { apiCache } from './lib/utils/cache.js';

export async function handler(event, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Only allow GET
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Check environment variables
    const envChecks = {
      openai: !!process.env.OPENAI_API_KEY,
      gemini: !!process.env.GEMINI_API_KEY,
      claude: !!process.env.ANTHROPIC_API_KEY
    };

    // Get cache stats
    const cacheStats = apiCache.getStats();

    // Calculate uptime (time since deployment)
    const uptime = process.uptime();

    const healthData = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      environment: {
        node_version: process.version,
        platform: process.platform,
        uptime_seconds: Math.floor(uptime)
      },
      services: {
        llm_providers: envChecks,
        cache: {
          enabled: true,
          entries: cacheStats.size,
          status: 'operational'
        }
      },
      endpoints: {
        deconstruct: '/api/deconstruct',
        simulate: '/api/simulate', 
        generate_image: '/api/generate-image',
        transcribe: '/api/transcribe',
        export: '/api/export',
        health: '/api/health'
      },
      rate_limits: {
        deconstruct: '10 requests per minute',
        simulate: '5 requests per 5 minutes',
        image: '3 requests per 5 minutes',
        transcribe: '5 requests per minute',
        export: '10 requests per 5 minutes'
      }
    };

    // Overall health status
    const allProvidersAvailable = Object.values(envChecks).some(available => available);
    if (!allProvidersAvailable) {
      healthData.status = 'degraded';
      healthData.warnings = ['No LLM providers configured'];
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(healthData, null, 2)
    };

  } catch (error) {
    console.error('Health check error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        status: 'unhealthy',
        error: 'Health check failed',
        timestamp: new Date().toISOString()
      })
    };
  }
}