#!/usr/bin/env node

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Serve static files
app.use(express.static(__dirname));
app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use('/fonts.googleapis.com', express.static(path.join(__dirname, 'fonts.googleapis.com')));

// API route handler for Netlify Functions
async function handleApiRoute(req, res, functionName) {
  try {
    // Import the specific API function
    const functionPath = path.join(__dirname, 'api', `${functionName}.js`);
    
    if (!fs.existsSync(functionPath)) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    const { handler } = await import(`./api/${functionName}.js`);
    
    // Create Netlify-style event object
    const event = {
      httpMethod: req.method,
      path: req.path,
      headers: req.headers,
      body: req.method === 'GET' ? null : JSON.stringify(req.body),
      queryStringParameters: req.query
    };

    // Call the handler
    const result = await handler(event, {});
    
    // Set headers from the result
    if (result.headers) {
      Object.entries(result.headers).forEach(([key, value]) => {
        res.set(key, value);
      });
    }

    // Send response
    res.status(result.statusCode || 200);
    
    if (result.headers && result.headers['Content-Type'] === 'application/json') {
      res.json(JSON.parse(result.body));
    } else {
      res.send(result.body);
    }
  } catch (error) {
    console.error(`Error in API function ${functionName}:`, error);
    res.status(500).json({ 
      error: 'Internal server error',
      message: error.message 
    });
  }
}

// API routes
app.get('/api/health', (req, res) => handleApiRoute(req, res, 'health'));
app.post('/api/deconstruct', (req, res) => handleApiRoute(req, res, 'deconstruct'));
app.post('/api/simulate', (req, res) => handleApiRoute(req, res, 'simulate'));
app.post('/api/generate-image', (req, res) => handleApiRoute(req, res, 'generate-image'));
app.post('/api/transcribe', (req, res) => handleApiRoute(req, res, 'transcribe'));
app.post('/api/export', (req, res) => handleApiRoute(req, res, 'export'));

// SPA fallback - serve index.html for all other routes
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Retro-Vision AI Server running at http://0.0.0.0:${PORT}`);
  console.log(`Local access: http://localhost:${PORT}`);
  console.log('API endpoints available:');
  console.log('  GET  /api/health');
  console.log('  POST /api/deconstruct');
  console.log('  POST /api/simulate');
  console.log('  POST /api/generate-image');
  console.log('  POST /api/transcribe');
  console.log('  POST /api/export');
});