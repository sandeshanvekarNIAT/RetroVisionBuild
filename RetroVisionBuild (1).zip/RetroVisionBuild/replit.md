# Retro-Vision AI

## Project Overview
A React-based web application called "Retro-Vision AI" that explores alternate invention histories with AI. The app allows users to discover how smartphones, computers, and other modern innovations could have emerged centuries earlier using historical knowledge and materials.

## Architecture
- **Frontend**: React application built with Vite
- **Styling**: Tailwind CSS for utility-first styling
- **Assets**: Compiled and optimized production build
- **Server**: Python HTTP server serving static files on port 5000

## Current State
The project now features a complete backend system for AI-powered invention analysis:
- ✅ React frontend serving on port 5000
- ✅ Complete Netlify Functions backend with multi-LLM capabilities
- ✅ Production-ready deployment configuration
- ✅ Multi-modal AI integration (text, images, audio, export)
- ✅ Smart caching and rate limiting system
- ✅ Server-side PDF generation with puppeteer

## Recent Changes
- **2025-09-16**: Project imported from GitHub/Lovable export
- **2025-09-16**: Python HTTP server created with SPA routing support  
- **2025-09-16**: Workflow configured for frontend serving
- **2025-09-16**: Complete backend system implemented with Netlify Functions
- **2025-09-16**: Multi-LLM provider system (OpenAI, Gemini, Claude) with fallbacks
- **2025-09-16**: API endpoints created: deconstruct, simulate, generate-image, transcribe, export
- **2025-09-16**: Rate limiting and caching system implemented
- **2025-09-16**: Server-side PDF/PPTX export functionality added
- **2025-09-16**: Netlify deployment configuration optimized for production

## Project Structure
```
├── assets/                    # Compiled frontend assets (CSS, JS, fonts, images)
├── fonts.googleapis.com/      # Google Fonts assets
├── api/                       # Netlify Functions backend
│   ├── deconstruct.js         # Invention analysis endpoint
│   ├── simulate.js            # Historical simulation endpoint
│   ├── generate-image.js      # AI image generation endpoint
│   ├── transcribe.js          # Audio transcription endpoint
│   ├── export.js              # PPTX/PDF export endpoint
│   ├── health.js              # System health check
│   └── lib/
│       ├── llm-providers/     # Multi-LLM system
│       │   ├── fallback.js    # Smart fallback logic
│       │   ├── openai.js      # OpenAI integration (primary)
│       │   ├── gemini.js      # Google Gemini (fallback 1)
│       │   └── claude.js      # Anthropic Claude (fallback 2)
│       └── utils/
│           ├── cache.js       # Response caching system
│           ├── rate-limit.js  # API rate limiting
│           ├── validation.js  # Input validation
│           └── export.js      # Export utilities
├── server.py                  # Python HTTP server for development
├── index.html                 # React app entry point
├── netlify.toml               # Netlify deployment configuration
├── package.json               # Node.js dependencies
├── .env.example               # Environment variables template
├── README.md                  # Setup and deployment guide
└── replit.md                  # This documentation
```

## User Preferences
- Clean, production-ready setup
- Static file serving approach for React SPA
- Standard port 5000 for frontend
- Autoscale deployment for cost efficiency

## Key Features

### Frontend
- Modern React application with professional UI
- Dark vintage theme with typography optimization
- Responsive design with proper meta tags
- Analytics integration ready

### Backend (Netlify Functions)
- **Multi-LLM Architecture**: OpenAI GPT-4o (primary), Google Gemini 1.5 Pro (fallback 1), Anthropic Claude 3.5 Sonnet (fallback 2)
- **Invention Analysis**: Deconstruct modern inventions into fundamental components
- **Historical Simulation**: Generate plausible alternate pathways for earlier invention
- **Visual Generation**: Create period-accurate blueprints and prototypes using DALL-E 3
- **Audio Processing**: Voice-powered invention input via OpenAI Whisper
- **Export Capabilities**: Generate PPTX presentations and PDF reports
- **Smart Caching**: Reduce API costs with intelligent response caching (TTL: 12-48 hours)
- **Rate Limiting**: Built-in protection against API abuse (per-endpoint limits)
- **Content Moderation**: Input validation and inappropriate content filtering

### Production Features
- Serverless architecture optimized for Netlify deployment
- Automatic fallback between AI providers for high reliability
- Server-side PDF generation using puppeteer + Chromium
- Cost optimization through caching and model selection
- Comprehensive error handling and logging
- CORS protection and security headers