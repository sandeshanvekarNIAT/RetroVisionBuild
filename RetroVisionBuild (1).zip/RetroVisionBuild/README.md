# AI Reverse-Invention Generator

A React-based web application that explores alternate invention histories with AI. Discover how smartphones, computers, and other modern innovations could have emerged centuries earlier using historical knowledge and materials.

## Features

- **Multi-Modal AI Analysis**: Uses OpenAI GPT-5, Google Gemini, and Anthropic Claude with automatic fallbacks
- **Invention Deconstruction**: Break down modern inventions into fundamental components
- **Historical Simulation**: Generate plausible alternate pathways for earlier invention
- **Visual Generation**: Create period-accurate blueprints and prototypes
- **Audio Input**: Voice-powered invention suggestions via Whisper
- **Export Capabilities**: Download results as PPTX presentations or PDF reports
- **Smart Caching**: Reduce API costs with intelligent response caching
- **Rate Limiting**: Built-in protection against API abuse

## Technology Stack

### Frontend
- React (pre-built static application)
- Tailwind CSS for styling
- Modern responsive design

### Backend
- Netlify Functions (Serverless)
- Node.js 18+
- Multi-LLM architecture with fallbacks

### AI Providers
- **OpenAI**: GPT-5, DALL-E 3, Whisper (Primary)
- **Google Gemini**: Gemini 2.5 Pro/Flash (Fallback 1)
- **Anthropic**: Claude Sonnet 4 (Fallback 2)

## Deployment on Netlify

### Prerequisites
1. Netlify account
2. API keys for AI providers (at least one required):
   - OpenAI API key
   - Google Gemini API key
   - Anthropic API key

### Setup Instructions

1. **Fork/Clone this repository**

2. **Connect to Netlify**
   - Connect your GitHub repository to Netlify
   - Choose this repository for deployment

3. **Configure Environment Variables**
   In your Netlify dashboard, go to Site settings → Environment variables and add:

   ```
   OPENAI_API_KEY=your_openai_api_key_here
   GEMINI_API_KEY=your_gemini_api_key_here
   ANTHROPIC_API_KEY=your_anthropic_api_key_here
   ```

   **Note**: You need at least one API key for the system to work. The application will automatically use available providers and fall back to others if needed.

4. **Deploy**
   - Push your code to GitHub
   - Netlify will automatically build and deploy
   - The build process will install dependencies and configure the serverless functions

5. **Verify Deployment**
   - Visit your deployed site URL
   - Check the health endpoint: `https://your-site.netlify.app/api/health`
   - Test the application with a simple invention

## API Endpoints

- `POST /api/deconstruct` - Analyze invention components
- `POST /api/simulate` - Generate alternate historical pathways
- `POST /api/generate-image` - Create visual prototypes
- `POST /api/transcribe` - Convert audio to text
- `POST /api/export` - Generate PPTX/PDF reports
- `GET /api/health` - System health check

## Rate Limits

- Deconstruct: 10 requests per minute
- Simulate: 5 requests per 5 minutes
- Images: 3 requests per 5 minutes
- Transcribe: 5 requests per minute
- Export: 10 requests per 5 minutes

## Local Development

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Set up environment**
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

3. **Run the development server**
   ```bash
   npm run dev
   ```

4. **Test the API**
   ```bash
   curl http://localhost:5000/api/health
   ```

## Usage Examples

### Deconstruct an Invention
```javascript
fetch('/api/deconstruct', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    invention: 'smartphone'
  })
})
```

### Generate Alternate Pathways
```javascript
fetch('/api/simulate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    invention: 'smartphone',
    era: '1800s',
    creativity: 0.7,
    depth: 3,
    decomposition: { /* result from deconstruct */ }
  })
})
```

### Generate Historical Images
```javascript
fetch('/api/generate-image', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    invention: 'smartphone',
    era: '1800s',
    pathwayDescription: 'Victorian-era communication device...',
    imageType: 'blueprint',
    style: 'technical blueprint'
  })
})
```

## Architecture

### Multi-LLM Fallback System
The application uses a sophisticated fallback system:
1. **Primary**: OpenAI GPT-5 (most capable, latest model)
2. **Fallback 1**: Google Gemini 2.5 Pro (strong alternative)
3. **Fallback 2**: Anthropic Claude Sonnet 4 (reliable backup)

If the primary provider fails, the system automatically tries the next available provider, ensuring high reliability.

### Caching Strategy
- Deconstructions: Cached for 24 hours
- Simulations: Cached for 12 hours  
- Images: Cached for 48 hours
- Smart cache keys based on input parameters

### Security Features
- Input validation and sanitization
- Content moderation for inappropriate requests
- Rate limiting per IP address
- CORS protection
- No API keys exposed to frontend

## Cost Optimization

- Aggressive caching reduces repeated API calls
- Smart model selection (cheaper models for analysis, premium for creativity)
- Rate limiting prevents abuse
- Fallback system ensures reliability without over-provisioning

## Troubleshooting

### Health Check Fails
- Verify at least one API key is configured
- Check Netlify function logs for errors
- Ensure environment variables are set correctly

### Images Not Generating
- OpenAI DALL-E 3 requires valid API key and credits
- Gemini image generation is in preview, may have limitations
- Check rate limits and try again later

### Audio Transcription Fails
- Ensure audio file is under 25MB
- Supported formats: MP3, WAV, M4A, AAC, OGG, FLAC
- OpenAI Whisper API key required for transcription

## License

MIT License - feel free to use and modify for your projects.

## Support

For issues and questions:
1. Check the health endpoint for system status
2. Review Netlify function logs
3. Verify API key configuration
4. Check rate limit headers in responses