import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { transcribeAudio } from "@/lib/api";

interface VoiceInputProps {
  onTranscription: (text: string) => void;
}

export function VoiceInput({ onTranscription }: VoiceInputProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const { toast } = useToast();

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const audioFile = new File([audioBlob], 'recording.wav', { type: 'audio/wav' });
        
        setIsProcessing(true);
        try {
          const result = await transcribeAudio(audioFile);
          onTranscription(result.text);
          toast({
            title: "Voice Input Successful",
            description: "Your speech has been transcribed.",
          });
        } catch (error) {
          console.error("Transcription failed:", error);
          toast({
            title: "Transcription Failed",
            description: "Could not process your voice input. Please try again.",
            variant: "destructive",
          });
        } finally {
          setIsProcessing(false);
        }
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);

      toast({
        title: "Recording Started",
        description: "Speak your invention idea now...",
      });
    } catch (error) {
      console.error("Could not start recording:", error);
      toast({
        title: "Recording Failed",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleClick = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={handleClick}
          disabled={isProcessing}
          className={`transition-colors duration-200 ${
            isRecording 
              ? "text-red-500 hover:text-red-600" 
              : "text-brass hover:text-copper"
          }`}
          data-testid="button-voice-input"
        >
          {isProcessing ? (
            <i className="fas fa-spinner animate-spin"></i>
          ) : isRecording ? (
            <i className="fas fa-stop-circle"></i>
          ) : (
            <i className="fas fa-microphone"></i>
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p>
          {isProcessing
            ? "Processing..."
            : isRecording
            ? "Click to stop recording"
            : "Click to start voice input"}
        </p>
      </TooltipContent>
    </Tooltip>
  );
}
