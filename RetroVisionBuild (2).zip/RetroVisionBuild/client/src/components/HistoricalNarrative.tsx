interface HistoricalNarrativeProps {
  narrative: string;
  invention: string;
  era: string;
}

export function HistoricalNarrative({ narrative, invention, era }: HistoricalNarrativeProps) {
  const formatEra = (era: string) => {
    const eraMap: Record<string, string> = {
      'ancient': 'Ancient Times',
      'medieval': 'Medieval Period',
      'renaissance': 'Renaissance',
      'enlightenment': 'Age of Enlightenment',
      'industrial': 'Industrial Revolution',
      'victorian': 'Victorian Era',
      'early-1900s': 'Early 20th Century'
    };
    return eraMap[era] || era;
  };

  return (
    <div className="vintage-card rounded-lg p-8" data-testid="historical-narrative">
      <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
        <i className="fas fa-feather-alt mr-3 text-brass"></i>
        Historical Chronicle Entry
      </h3>

      <div className="p-6 bg-parchment-light border-2 border-brass rounded-lg">
        <div className="text-center mb-6">
          <h4 className="text-xl font-serif font-bold text-foreground" data-testid="narrative-title">
            The {invention}: A Revolutionary Innovation of the {formatEra(era)}
          </h4>
          <p className="text-sm text-muted-foreground italic" data-testid="narrative-attribution">
            From "Chronicles of Technological Innovation" by the Retro-Vision Research Institute
          </p>
        </div>

        <div className="prose prose-sm text-foreground leading-relaxed max-w-none" data-testid="narrative-content">
          {narrative.split('\n\n').map((paragraph, index) => (
            <p key={index} className="mb-4">
              {paragraph}
            </p>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-brass/30">
          <p className="text-xs text-muted-foreground italic text-center">
            <i className="fas fa-quote-left mr-1"></i>
            Generated historical narrative based on alternate timeline simulation
            <i className="fas fa-quote-right ml-1"></i>
          </p>
        </div>
      </div>
    </div>
  );
}
