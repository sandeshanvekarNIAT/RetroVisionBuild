import { useState } from "react";
import { InputForm } from "@/components/InputForm";
import { ResultsView } from "@/components/ResultsView";
import type { DecompositionResponse, SimulationResponse, GeneratedImagesResponse } from "@shared/schema";

interface GenerationResults {
  invention: string;
  era: string;
  decomposition?: DecompositionResponse;
  pathways?: SimulationResponse['pathways'];
  images?: GeneratedImagesResponse['images'];
  narrative?: string;
}

export default function Home() {
  const [results, setResults] = useState<GenerationResults | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerationComplete = (data: GenerationResults) => {
    setResults(data);
    setIsGenerating(false);
  };

  const handleGenerationStart = () => {
    setIsGenerating(true);
    setResults(null);
  };

  return (
    <div className="min-h-screen bg-background vintage-texture">
      {/* Header */}
      <header className="bg-gradient-to-r from-mahogany-dark to-mahogany border-b-4 border-brass shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <i className="fas fa-cogs text-brass text-4xl gear-animation"></i>
                <div>
                  <h1 className="text-3xl font-serif font-bold text-brass">Retro-Vision</h1>
                  <p className="text-sm text-brass/80 font-medium">AI Reverse-Invention Generator</p>
                </div>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="text-brass hover:text-brass-light font-medium transition-colors duration-200">
                <i className="fas fa-home mr-2"></i>Home
              </a>
              <a href="#" className="text-brass hover:text-brass-light font-medium transition-colors duration-200">
                <i className="fas fa-history mr-2"></i>Gallery
              </a>
              <a href="#" className="text-brass hover:text-brass-light font-medium transition-colors duration-200">
                <i className="fas fa-question-circle mr-2"></i>About
              </a>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <section className="text-center mb-12">
          <div className="vintage-card rounded-lg p-8 mb-8">
            <h2 className="text-5xl font-serif font-bold text-foreground mb-4">
              Reimagine History's Lost Inventions
            </h2>
            <p className="text-xl text-muted-foreground mb-6 max-w-3xl mx-auto leading-relaxed">
              What if the smartphone existed in the 1800s? What if steam engines led to computers instead of trains? 
              Explore alternate invention pathways and discover the fascinating "what-ifs" of technological history.
            </p>
            <div className="flex justify-center space-x-4">
              <div className="text-center">
                <i className="fas fa-microscope text-brass text-3xl mb-2"></i>
                <p className="text-sm text-muted-foreground">Deconstruct</p>
              </div>
              <div className="text-center">
                <i className="fas fa-clock text-brass text-3xl mb-2"></i>
                <p className="text-sm text-muted-foreground">Simulate</p>
              </div>
              <div className="text-center">
                <i className="fas fa-palette text-brass text-3xl mb-2"></i>
                <p className="text-sm text-muted-foreground">Visualize</p>
              </div>
              <div className="text-center">
                <i className="fas fa-book text-brass text-3xl mb-2"></i>
                <p className="text-sm text-muted-foreground">Narrate</p>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <InputForm 
            onGenerationStart={handleGenerationStart}
            onGenerationComplete={handleGenerationComplete}
            isGenerating={isGenerating}
          />
          
          {/* Example Preview */}
          <section className="vintage-card rounded-lg p-8">
            <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
              <i className="fas fa-eye mr-3 text-brass"></i>
              Example: Victorian Smartphone
            </h3>
            
            <div className="mb-6 overflow-hidden rounded-lg border-2 border-brass">
              <img 
                src="https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500" 
                alt="Victorian steampunk technical drawing" 
                className="w-full h-48 object-cover"
              />
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-parchment-light border border-brass/50 rounded">
                <h4 className="font-semibold text-foreground mb-2">
                  <i className="fas fa-lightbulb text-brass mr-2"></i>Core Innovation
                </h4>
                <p className="text-sm text-muted-foreground">
                  The "Telegraph Phone" of 1825 combined Morse code transmission with mechanical display drums, 
                  powered by spring mechanisms and early battery technology.
                </p>
              </div>

              <div className="p-4 bg-parchment-light border border-brass/50 rounded">
                <h4 className="font-semibold text-foreground mb-2">
                  <i className="fas fa-star text-brass mr-2"></i>Feasibility Score
                </h4>
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    {Array(7).fill(0).map((_, i) => (
                      <i key={i} className="fas fa-star text-brass"></i>
                    ))}
                    <i className="far fa-star text-brass/30"></i>
                    <i className="far fa-star text-brass/30"></i>
                    <i className="far fa-star text-brass/30"></i>
                  </div>
                  <span className="text-sm text-muted-foreground">7/10 - Highly Plausible</span>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Results Section */}
        {results && (
          <ResultsView results={results} />
        )}

        {/* Call to Action */}
        <section className="vintage-card rounded-lg p-8 text-center">
          <h3 className="text-2xl font-serif font-bold text-foreground mb-4">
            Explore More Alternate Histories
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Discover how different historical conditions could have led to fascinating technological developments. 
            From ancient computing to medieval aviation, the possibilities are endless.
          </p>
          <div className="flex justify-center space-x-4">
            <button className="steampunk-button text-brass-foreground py-3 px-6 rounded-lg font-semibold">
              <i className="fas fa-random mr-2"></i>Random Invention
            </button>
            <button className="bg-brass/20 hover:bg-brass/30 text-brass border border-brass py-3 px-6 rounded-lg font-semibold transition-colors duration-200">
              <i className="fas fa-history mr-2"></i>Browse Gallery
            </button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-mahogany-dark to-mahogany border-t-4 border-brass mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <i className="fas fa-cogs text-brass text-2xl"></i>
                <div>
                  <h3 className="text-lg font-serif font-bold text-brass">Retro-Vision</h3>
                  <p className="text-xs text-brass/80">AI Reverse-Invention Generator</p>
                </div>
              </div>
              <p className="text-sm text-brass/80 leading-relaxed">
                Reimagine history's lost inventions and explore alternate technological pathways 
                through the power of artificial intelligence.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-brass mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-brass/80">
                <li><i className="fas fa-check-circle mr-2"></i>AI-Powered Deconstruction</li>
                <li><i className="fas fa-check-circle mr-2"></i>Timeline Simulation</li>
                <li><i className="fas fa-check-circle mr-2"></i>Visual Prototype Generation</li>
                <li><i className="fas fa-check-circle mr-2"></i>Historical Narratives</li>
                <li><i className="fas fa-check-circle mr-2"></i>Export to PDF/PPTX</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-brass mb-4">Technology</h4>
              <ul className="space-y-2 text-sm text-brass/80">
                <li><i className="fas fa-brain mr-2"></i>OpenAI GPT-5 & DALL-E</li>
                <li><i className="fas fa-microphone mr-2"></i>Whisper Voice Recognition</li>
                <li><i className="fas fa-database mr-2"></i>Intelligent Caching</li>
                <li><i className="fas fa-shield-alt mr-2"></i>Rate Limiting & Security</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-brass/30 mt-8 pt-8 text-center">
            <p className="text-sm text-brass/60">
              © 2024 Retro-Vision. Powered by OpenAI and the imagination of alternate histories.
              <br />
              <span className="text-xs">Built with React, Node.js, and vintage craftsmanship.</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
