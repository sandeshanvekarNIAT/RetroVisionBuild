import { apiRequest } from "@/lib/queryClient";
import type { 
  DeconstructRequest,
  SimulateRequest,
  GenerateImageRequest,
  ExportRequest,
  DecompositionResponse,
  SimulationResponse,
  GeneratedImagesResponse
} from "@shared/schema";

export async function deconstructInvention(data: DeconstructRequest) {
  const response = await apiRequest("POST", "/api/deconstruct", data);
  return response.json() as Promise<{ decomposition: DecompositionResponse }>;
}

export async function simulatePathways(data: SimulateRequest) {
  const response = await apiRequest("POST", "/api/simulate", data);
  return response.json() as Promise<SimulationResponse>;
}

export async function generateImages(data: GenerateImageRequest) {
  const response = await apiRequest("POST", "/api/generate-image", data);
  return response.json() as Promise<GeneratedImagesResponse>;
}

export async function generateNarrative(invention: string, era: string, pathways: any[]) {
  const response = await apiRequest("POST", "/api/generate-narrative", { invention, era, pathways });
  return response.json() as Promise<{ narrative: string }>;
}

export async function transcribeAudio(audioFile: File) {
  const formData = new FormData();
  formData.append('audio', audioFile);
  
  const response = await fetch('/api/transcribe', {
    method: 'POST',
    body: formData,
    credentials: 'include',
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`${response.status}: ${error}`);
  }
  
  return response.json() as Promise<{ text: string }>;
}

export async function exportToPPTX(data: ExportRequest) {
  const response = await apiRequest("POST", "/api/export/pptx", data);
  return response.blob();
}

export async function exportToPDF(data: ExportRequest) {
  const response = await apiRequest("POST", "/api/export/pdf", data);
  return response.blob();
}

export async function getHealthCheck() {
  const response = await apiRequest("GET", "/api/health");
  return response.json();
}

export async function getApiStats() {
  const response = await apiRequest("GET", "/api/stats");
  return response.json();
}
