# Retro-Vision - AI Reverse-Invention Generator

## Overview

Retro-Vision is a vintage-themed AI web application that reverse-engineers modern inventions to simulate alternate historical pathways. Users input an invention (like "smartphone") and a historical era (like "Victorian Era"), and the system generates plausible alternate invention timelines, complete with visual prototypes and historical narratives. The app uses OpenAI's GPT-5, DALL-E 3, and Whisper APIs to deconstruct inventions, simulate pathways, generate period-accurate images, and support voice input. Features include a steampunk-styled UI, PDF/PowerPoint export capabilities, and comprehensive caching to optimize API costs.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with Vite**: Modern build tooling for fast development and optimized production builds
- **TypeScript**: Type safety across the entire codebase with shared schemas
- **Tailwind CSS**: Utility-first styling with custom vintage/steampunk theming using brass, copper, and mahogany color schemes
- **shadcn/ui Components**: Comprehensive UI component library built on Radix UI primitives
- **TanStack Query**: Client-side state management and API caching for optimal performance
- **Wouter**: Lightweight client-side routing solution
- **React Hook Form + Zod**: Form handling with robust validation

### Backend Architecture
- **Express.js**: RESTful API server with middleware for rate limiting and error handling
- **TypeScript**: Consistent typing across frontend and backend
- **Modular Service Layer**: Separated concerns for OpenAI integration, caching, exports, and data storage
- **Rate Limiting**: Multi-tier protection with different limits for general, heavy, and image generation endpoints
- **Multer**: File upload handling for audio transcription features

### Data Storage Solutions
- **PostgreSQL with Drizzle ORM**: Primary database for persistent data with type-safe queries
- **In-Memory Caching**: NodeCache for API response caching to reduce OpenAI costs and improve performance
- **Memory Storage Fallback**: Complete in-memory implementation for development and testing environments

### Authentication and Authorization
- **Session-based Authentication**: User authentication with session management
- **PostgreSQL Sessions**: Persistent session storage using connect-pg-simple

### Core AI Processing Pipeline
- **Invention Deconstruction**: GPT-5 breaks down inventions into components, materials, sciences, and cultural drivers
- **Timeline Simulation**: Generates 3-7 alternate pathways for specified historical eras with feasibility scoring
- **Visual Generation**: DALL-E 3 creates period-accurate technical drawings and prototypes
- **Narrative Creation**: AI-generated historical chronicles describing invention impact
- **Content Moderation**: OpenAI moderation API ensures safe, appropriate content

## External Dependencies

### OpenAI APIs
- **GPT-5**: Primary language model for invention analysis and content generation
- **DALL-E 3**: Image generation for historical prototype visualizations  
- **Whisper**: Audio transcription for voice input functionality
- **Moderation API**: Content safety and filtering

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling
- **Drizzle Kit**: Database migration and schema management tools

### Development and Deployment
- **Vite**: Frontend build tool with HMR and optimization
- **Replit Integration**: Custom plugins for development environment and deployment
- **esbuild**: Backend bundling for production deployments

### Export and Document Generation
- **PptxGenJS**: PowerPoint presentation generation
- **jsPDF**: PDF document creation and export
- **HTML to PDF Conversion**: Alternative PDF generation pathway

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **class-variance-authority**: Component variant management
- **zod**: Schema validation across the application stack
- **nanoid**: Unique identifier generation