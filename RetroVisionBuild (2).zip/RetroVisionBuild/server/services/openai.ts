import fs from "fs";
import ffmpeg from "fluent-ffmpeg";
import ffmpegStatic from "ffmpeg-static";

// Set ffmpeg path
if (ffmpegStatic) {
  ffmpeg.setFfmpegPath(ffmpegStatic);
}

// Hugging Face configuration
const HF_API_TOKEN = process.env.HF_API_TOKEN;
const HF_TEXT_MODEL = process.env.HF_TEXT_MODEL || "mistralai/Mistral-7B-Instruct-v0.1";
const HF_IMAGE_MODEL = process.env.HF_IMAGE_MODEL || "black-forest-labs/FLUX.1-dev";
const HF_SPEECH_MODEL = process.env.HF_SPEECH_MODEL || "openai/whisper-large-v3";

// Configuration validation
if (!HF_API_TOKEN) {
  throw new Error("Hugging Face API token not found. Please set HF_API_TOKEN in environment variables.");
}

console.log("AI Service Configuration:");
console.log(`- Text generation: ${HF_TEXT_MODEL}`);
console.log(`- Image generation: ${HF_IMAGE_MODEL}`);
console.log(`- Speech recognition: ${HF_SPEECH_MODEL}`);

// Helper function for API calls with timeout
async function fetchWithTimeout(url: string, options: RequestInit, timeout = 30000): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

export async function callGPT(
  systemPrompt: string, 
  userPrompt: string, 
  temperature = 0.3, 
  maxTokens = 1500,
  responseFormat: "text" | "json" = "text"
): Promise<string> {
  try {
    const messages = `<|system|>${systemPrompt}<|user|>${userPrompt}<|assistant|>`;
    
    const response = await fetchWithTimeout(
      `https://api-inference.huggingface.co/models/${HF_TEXT_MODEL}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HF_API_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: messages,
          parameters: {
            temperature,
            max_new_tokens: maxTokens,
            return_full_text: false
          }
        })
      },
      60000 // 60 second timeout for text generation
    );

    if (!response.ok) {
      throw new Error(`Hugging Face text API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const generatedText = data[0]?.generated_text || data.generated_text || "";
    
    // If JSON format requested, try to extract JSON from response
    if (responseFormat === "json") {
      try {
        // Try to find JSON in the response
        const jsonMatch = generatedText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          return jsonMatch[0];
        }
      } catch (e) {
        // If JSON extraction fails, return as-is
      }
    }
    
    return generatedText;
  } catch (error) {
    console.error("Hugging Face text generation error:", error);
    throw new Error(`Failed to generate text: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateImage(
  prompt: string, 
  size: "512x512" | "1024x1024" = "1024x1024", 
  n = 1
): Promise<{ url: string; id: string }[]> {
  const results: { url: string; id: string }[] = [];
  
  for (let i = 0; i < n; i++) {
    try {
      const response = await fetchWithTimeout(
        `https://api-inference.huggingface.co/models/${HF_IMAGE_MODEL}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${HF_API_TOKEN}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            inputs: prompt,
            parameters: {
              width: parseInt(size.split('x')[0]),
              height: parseInt(size.split('x')[1])
            }
          })
        }
      );

      if (!response.ok) {
        throw new Error(`Hugging Face image API error: ${response.status} ${response.statusText}`);
      }

      const imageBuffer = await response.arrayBuffer();
      const base64Image = Buffer.from(imageBuffer).toString('base64');
      const dataUrl = `data:image/png;base64,${base64Image}`;
      
      results.push({
        url: dataUrl,
        id: `img_${Date.now()}_${i}`
      });
    } catch (error) {
      console.error("Hugging Face image generation error:", error);
      throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  return results;
}

export async function transcribeAudio(audioBuffer: Buffer, filename: string): Promise<{ text: string }> {
  // Use secure temp file naming to prevent path traversal
  const secureFilename = `audio_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  const tempPath = `/tmp/${secureFilename}`;
  const convertedPath = `/tmp/converted_${secureFilename}.wav`;
  
  fs.writeFileSync(tempPath, audioBuffer);

  try {
    // Convert audio to required format
    await new Promise<void>((resolve, reject) => {
      ffmpeg(tempPath)
        .toFormat('wav')
        .audioFrequency(16000)
        .audioChannels(1)
        .audioCodec('pcm_s16le')
        .on('end', () => resolve())
        .on('error', (err) => reject(err))
        .save(convertedPath);
    });

    const convertedBuffer = fs.readFileSync(convertedPath);
    
    const response = await fetchWithTimeout(
      `https://api-inference.huggingface.co/models/${HF_SPEECH_MODEL}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HF_API_TOKEN}`,
          'Content-Type': 'audio/wav',
        },
        body: convertedBuffer
      }
    );

    if (!response.ok) {
      throw new Error(`Hugging Face speech API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    return {
      text: result.text || ""
    };
  } catch (error) {
    console.error("Hugging Face speech transcription error:", error);
    throw new Error(`Failed to transcribe audio: ${error instanceof Error ? error.message : 'Unknown error'}`);
  } finally {
    // Clean up temporary files
    [tempPath, convertedPath].forEach(path => {
      if (fs.existsSync(path)) {
        fs.unlinkSync(path);
      }
    });
  }
}

export async function moderateContent(text: string): Promise<{ flagged: boolean; categories: string[] }> {
  // Simple content moderation using blocklist
  const blocklist = [
    'violence',
    'hate',
    'harassment',
    'self-harm',
    'sexual',
    'illegal',
    'harmful',
    'dangerous'
  ];
  
  const lowerText = text.toLowerCase();
  const flaggedCategories = blocklist.filter(term => 
    lowerText.includes(term)
  );
  
  return {
    flagged: flaggedCategories.length > 0,
    categories: flaggedCategories
  };
}