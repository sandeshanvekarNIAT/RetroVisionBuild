import { 
  type User, 
  type InsertUser, 
  type Invention, 
  type InsertInvention,
  type GenerationCache,
  type ApiUsage 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getInvention(id: string): Promise<Invention | undefined>;
  createInvention(invention: InsertInvention): Promise<Invention>;
  updateInvention(id: string, updates: Partial<Invention>): Promise<Invention | undefined>;
  getInventionsByUser(userId: string): Promise<Invention[]>;
  
  getCacheEntry(cacheKey: string): Promise<GenerationCache | undefined>;
  setCacheEntry(cacheKey: string, response: any, expiresAt: Date): Promise<GenerationCache>;
  cleanExpiredCache(): Promise<void>;
  
  logApiUsage(endpoint: string, tokensUsed?: number, cost?: number, success?: boolean): Promise<ApiUsage>;
  getApiUsageStats(timeframe?: Date): Promise<{ totalCost: number; totalTokens: number; totalRequests: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private inventions: Map<string, Invention>;
  private cache: Map<string, GenerationCache>;
  private apiUsage: ApiUsage[];

  constructor() {
    this.users = new Map();
    this.inventions = new Map();
    this.cache = new Map();
    this.apiUsage = [];
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getInvention(id: string): Promise<Invention | undefined> {
    return this.inventions.get(id);
  }

  async createInvention(insertInvention: InsertInvention): Promise<Invention> {
    const id = randomUUID();
    const invention: Invention = {
      id,
      ...insertInvention,
      decomposition: null,
      pathways: null,
      images: null,
      narrative: null,
      createdAt: new Date(),
      userId: null
    };
    this.inventions.set(id, invention);
    return invention;
  }

  async updateInvention(id: string, updates: Partial<Invention>): Promise<Invention | undefined> {
    const existing = this.inventions.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.inventions.set(id, updated);
    return updated;
  }

  async getInventionsByUser(userId: string): Promise<Invention[]> {
    return Array.from(this.inventions.values()).filter(
      invention => invention.userId === userId
    );
  }

  async getCacheEntry(cacheKey: string): Promise<GenerationCache | undefined> {
    const entry = this.cache.get(cacheKey);
    if (entry && entry.expiresAt > new Date()) {
      return entry;
    }
    if (entry) {
      this.cache.delete(cacheKey);
    }
    return undefined;
  }

  async setCacheEntry(cacheKey: string, response: any, expiresAt: Date): Promise<GenerationCache> {
    const id = randomUUID();
    const entry: GenerationCache = {
      id,
      cacheKey,
      response,
      expiresAt,
      createdAt: new Date()
    };
    this.cache.set(cacheKey, entry);
    return entry;
  }

  async cleanExpiredCache(): Promise<void> {
    const now = new Date();
    const entries = Array.from(this.cache.entries());
    for (const [key, entry] of entries) {
      if (entry.expiresAt <= now) {
        this.cache.delete(key);
      }
    }
  }

  async logApiUsage(
    endpoint: string, 
    tokensUsed?: number, 
    cost?: number, 
    success: boolean = true
  ): Promise<ApiUsage> {
    const id = randomUUID();
    const usage: ApiUsage = {
      id,
      endpoint,
      tokensUsed: tokensUsed || null,
      cost: cost || null,
      success,
      timestamp: new Date()
    };
    this.apiUsage.push(usage);
    return usage;
  }

  async getApiUsageStats(timeframe?: Date): Promise<{ totalCost: number; totalTokens: number; totalRequests: number }> {
    const since = timeframe || new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours ago
    const relevantUsage = this.apiUsage.filter(usage => usage.timestamp && usage.timestamp >= since);
    
    return {
      totalCost: relevantUsage.reduce((sum, usage) => sum + (usage.cost || 0), 0),
      totalTokens: relevantUsage.reduce((sum, usage) => sum + (usage.tokensUsed || 0), 0),
      totalRequests: relevantUsage.length
    };
  }
}

export const storage = new MemStorage();
