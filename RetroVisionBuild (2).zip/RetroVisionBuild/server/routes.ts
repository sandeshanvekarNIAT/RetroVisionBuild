import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { 
  deconstructRequestSchema,
  simulateRequestSchema,
  generateImageRequestSchema,
  exportRequestSchema,
  type DecompositionResponse,
  type SimulationResponse,
  type GeneratedImagesResponse
} from "@shared/schema";
import { callGPT, generateImage, transcribeAudio, moderateContent } from "./services/openai";
import { 
  createDeconstructionPrompt, 
  createSimulationPrompt, 
  createImagePrompt, 
  createNarrativePrompt,
  DECONSTRUCTION_SYSTEM_PROMPT,
  SIMULATION_SYSTEM_PROMPT,
  NARRATIVE_SYSTEM_PROMPT
} from "./services/prompts";
import { 
  getCachedDecomposition, 
  setCachedDecomposition,
  getCachedSimulation,
  setCachedSimulation,
  getCachedImage,
  setCachedImage
} from "./services/cache";
import { createPPTX, createPDF } from "./services/exports";
import { generalRateLimit, heavyRateLimit, imageRateLimit } from "./middleware/rateLimiter";

// Configure multer for audio uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/mp4', 'audio/webm'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only audio files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Deconstruct invention endpoint
  app.post('/api/deconstruct', heavyRateLimit, async (req, res) => {
    try {
      const { invention } = deconstructRequestSchema.parse(req.body);
      
      // Check moderation
      const moderation = await moderateContent(invention);
      if (moderation.flagged) {
        return res.status(400).json({ 
          error: 'Content flagged by moderation', 
          categories: moderation.categories 
        });
      }

      // Check cache first
      let decomposition = getCachedDecomposition(invention);
      
      if (!decomposition) {
        const systemPrompt = DECONSTRUCTION_SYSTEM_PROMPT;
        const userPrompt = createDeconstructionPrompt(invention);
        
        const response = await callGPT(systemPrompt, userPrompt, 0.2, 1500, "json");
        decomposition = JSON.parse(response) as DecompositionResponse;
        
        // Cache for 24 hours
        setCachedDecomposition(invention, decomposition, { ttl: 86400 });
        
        // Log API usage
        await storage.logApiUsage('/api/deconstruct', 1500, 0.03, true);
      }

      res.json({ decomposition });
    } catch (error: any) {
      console.error('Deconstruction error:', error);
      await storage.logApiUsage('/api/deconstruct', 0, 0, false);
      
      // Handle specific OpenAI errors
      if (error.status === 429) {
        return res.status(429).json({ 
          error: 'OpenAI API quota exceeded', 
          message: 'Your OpenAI API quota has been exceeded. Please check your billing and usage limits.',
          userMessage: 'AI quota exceeded. Please try again later or check your OpenAI account.'
        });
      } else if (error.status === 401) {
        return res.status(401).json({ 
          error: 'OpenAI API authentication failed', 
          message: 'Invalid OpenAI API key.',
          userMessage: 'AI service authentication failed. Please check configuration.'
        });
      }
      
      res.status(500).json({ 
        error: 'Failed to deconstruct invention',
        userMessage: 'Unable to analyze the invention. Please try again.'
      });
    }
  });

  // Simulate alternate pathways endpoint
  app.post('/api/simulate', heavyRateLimit, async (req, res) => {
    try {
      const { invention, era, depth, creativity } = simulateRequestSchema.parse(req.body);
      
      // Check moderation
      const moderation = await moderateContent(`${invention} ${era}`);
      if (moderation.flagged) {
        return res.status(400).json({ 
          error: 'Content flagged by moderation', 
          categories: moderation.categories 
        });
      }

      // Check cache first
      let simulation = getCachedSimulation(invention, era, creativity, depth);
      
      if (!simulation) {
        // Get decomposition first
        let decomposition = getCachedDecomposition(invention);
        if (!decomposition) {
          const decompResponse = await callGPT(
            DECONSTRUCTION_SYSTEM_PROMPT, 
            createDeconstructionPrompt(invention), 
            0.2, 
            1500, 
            "json"
          );
          decomposition = JSON.parse(decompResponse);
          setCachedDecomposition(invention, decomposition, { ttl: 86400 });
        }

        // Generate simulation
        const systemPrompt = SIMULATION_SYSTEM_PROMPT;
        const userPrompt = createSimulationPrompt(invention, era, decomposition, depth);
        
        const response = await callGPT(systemPrompt, userPrompt, creativity, 2000, "json");
        const simulationData = JSON.parse(response) as SimulationResponse;
        
        // Add unique IDs to pathways
        simulationData.pathways = simulationData.pathways.map((pathway, index) => ({
          ...pathway,
          id: `pathway_${Date.now()}_${index}`
        }));
        
        simulation = simulationData;
        
        // Cache for 6 hours
        setCachedSimulation(invention, era, creativity, depth, simulation, { ttl: 21600 });
        
        // Log API usage
        await storage.logApiUsage('/api/simulate', 2000, 0.06, true);
      }

      res.json(simulation);
    } catch (error) {
      console.error('Simulation error:', error);
      await storage.logApiUsage('/api/simulate', 0, 0, false);
      res.status(500).json({ error: 'Failed to simulate pathways' });
    }
  });

  // Generate images endpoint
  app.post('/api/generate-image', imageRateLimit, async (req, res) => {
    try {
      const { prompt, style, size } = generateImageRequestSchema.parse(req.body);
      
      // Check moderation
      const moderation = await moderateContent(prompt);
      if (moderation.flagged) {
        return res.status(400).json({ 
          error: 'Content flagged by moderation', 
          categories: moderation.categories 
        });
      }

      // Check cache first
      let images = getCachedImage(prompt, style);
      
      if (!images) {
        const imageData = await generateImage(prompt, size);
        
        images = {
          images: imageData.map((img, index) => ({
            id: img.id,
            url: img.url,
            title: `Generated Image ${index + 1}`,
            description: prompt
          }))
        };
        
        // Cache for 12 hours
        setCachedImage(prompt, images, style, { ttl: 43200 });
        
        // Log API usage (DALL-E is more expensive)
        await storage.logApiUsage('/api/generate-image', 0, 0.08, true);
      }

      res.json(images);
    } catch (error) {
      console.error('Image generation error:', error);
      await storage.logApiUsage('/api/generate-image', 0, 0, false);
      res.status(500).json({ error: 'Failed to generate images' });
    }
  });

  // Generate historical narrative endpoint
  app.post('/api/generate-narrative', heavyRateLimit, async (req, res) => {
    try {
      const { invention, era, pathways } = req.body;
      
      if (!invention || !era || !pathways) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const systemPrompt = NARRATIVE_SYSTEM_PROMPT;
      const userPrompt = createNarrativePrompt(invention, era, pathways);
      
      const narrative = await callGPT(systemPrompt, userPrompt, 0.7, 2000);
      
      // Log API usage
      await storage.logApiUsage('/api/generate-narrative', 2000, 0.06, true);
      
      res.json({ narrative });
    } catch (error) {
      console.error('Narrative generation error:', error);
      await storage.logApiUsage('/api/generate-narrative', 0, 0, false);
      res.status(500).json({ error: 'Failed to generate narrative' });
    }
  });

  // Transcribe audio endpoint
  app.post('/api/transcribe', generalRateLimit, upload.single('audio'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No audio file provided' });
      }

      const result = await transcribeAudio(req.file.buffer, req.file.originalname);
      
      // Log API usage
      await storage.logApiUsage('/api/transcribe', 0, 0.02, true);
      
      res.json(result);
    } catch (error) {
      console.error('Transcription error:', error);
      await storage.logApiUsage('/api/transcribe', 0, 0, false);
      res.status(500).json({ error: 'Failed to transcribe audio' });
    }
  });

  // Export endpoints
  app.post('/api/export/pptx', generalRateLimit, async (req, res) => {
    try {
      const data = exportRequestSchema.parse(req.body);
      const pptxBuffer = await createPPTX(data);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
      res.setHeader('Content-Disposition', `attachment; filename="${data.title}.pptx"`);
      res.send(pptxBuffer);
    } catch (error) {
      console.error('PPTX export error:', error);
      res.status(500).json({ error: 'Failed to export PPTX' });
    }
  });

  app.post('/api/export/pdf', generalRateLimit, async (req, res) => {
    try {
      const data = exportRequestSchema.parse(req.body);
      const pdfBuffer = await createPDF(data);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${data.title}.pdf"`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error('PDF export error:', error);
      res.status(500).json({ error: 'Failed to export PDF' });
    }
  });

  // API usage stats endpoint
  app.get('/api/stats', generalRateLimit, async (req, res) => {
    try {
      const stats = await storage.getApiUsageStats();
      res.json(stats);
    } catch (error) {
      console.error('Stats error:', error);
      res.status(500).json({ error: 'Failed to get stats' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
