import { RateLimiterMemory } from "rate-limiter-flexible";
import { Request, Response, NextFunction } from "express";

// Rate limiters for different endpoints
const generalLimiter = new RateLimiterMemory({
  points: 100, // Number of requests
  duration: 60, // Per 60 seconds
});

const heavyLimiter = new RateLimiterMemory({
  points: 10, // Number of requests
  duration: 300, // Per 5 minutes (300 seconds)
});

const imageLimiter = new RateLimiterMemory({
  points: 5, // Number of requests
  duration: 600, // Per 10 minutes (600 seconds)
});

export function createRateLimiter(limiter: RateLimiterMemory) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await limiter.consume(req.ip || 'unknown');
      next();
    } catch (rejRes: any) {
      const secs = Math.round(rejRes.msBeforeNext / 1000) || 1;
      res.set('Retry-After', String(secs));
      res.status(429).json({
        error: 'Too Many Requests',
        message: `Rate limit exceeded. Please try again in ${secs} seconds.`,
        retryAfter: secs
      });
    }
  };
}

export const generalRateLimit = createRateLimiter(generalLimiter);
export const heavyRateLimit = createRateLimiter(heavyLimiter);
export const imageRateLimit = createRateLimiter(imageLimiter);
