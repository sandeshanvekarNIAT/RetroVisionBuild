# Retro-Vision - AI Reverse-Invention Generator

A vintage-themed AI web application that reverse-engineers inventions to simulate alternate historical pathways with visual prototypes and narratives.

## 🎯 Project Overview

Retro-Vision allows users to explore fascinating "what-if" scenarios in technological history. What if the smartphone existed in the 1800s? What if steam engines led to computers instead of trains? This application uses AI to deconstruct inventions, simulate alternate historical pathways, and generate visual prototypes with compelling narratives.

## ✨ Features

### Core Functionality
- **AI-Powered Deconstruction**: Uses GPT-5 to break down inventions into fundamental components, materials, sciences, and cultural drivers
- **Timeline Simulation**: Generates 3-7 alternate invention pathways for specified historical eras
- **Visual Prototype Generation**: Creates period-accurate images using DALL-E 3
- **Historical Narratives**: AI-generated authentic period stories describing the invention's impact
- **Voice Input Support**: Whisper-powered audio transcription for hands-free invention entry

### User Experience
- **Vintage Steampunk UI**: Beautiful Victorian-era themed interface with brass, copper, and mahogany styling
- **Interactive Results Dashboard**: Collapsible cards for decomposition, timelines, and narratives
- **Export Functionality**: Generate PDF reports and PowerPoint presentations
- **Real-time Progress Tracking**: Visual feedback during AI generation process

### Technical Features
- **Intelligent Caching**: Reduces API costs and improves response times
- **Rate Limiting**: Protects against abuse and controls costs
- **Content Moderation**: OpenAI moderation for safe content
- **Error Handling**: Comprehensive error management with user-friendly messages

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- OpenAI API key

### Installation

1. **Clone and Install**
   ```bash
   npm install
   ```

2. **Environment Setup**
   
   Add your OpenAI API key to Replit Secrets:
   - Go to Replit Secrets (lock icon in sidebar)
   - Add key: `OPENAI_API_KEY`
   - Value: Your OpenAI API key

   Optional environment variables:
   ```bash
   GPT_MODEL=gpt-5              # Default AI model
   IMAGE_MODEL=dall-e-3         # Image generation model
   ```

3. **Run the Application**
   ```bash
   npm run dev
   ```

4. **Access the App**
   - The app will be available on your Replit URL
   - Frontend and backend run on port 5000

## 🧪 Testing the Application

### Manual Test Example

1. **Navigate to the application**
2. **Enter invention**: "Smartphone"
3. **Select era**: "Victorian Era (1837-1901)"
4. **Set creativity**: 0.8 (more imaginative)
5. **Choose depth**: 5 pathways
6. **Click "Generate Alternate History"**

**Expected Results:**
- Decomposition showing core functions (communication, display, battery, computing)
- 5 alternate pathways like "Telegraph Phone", "Victorian Communicator"
- Each pathway with feasibility scores, technical steps, and prototype descriptions
- Generated images showing Victorian-era smartphone designs
- Historical narrative describing social impact in Victorian society
- Downloadable PDF/PPTX exports

### Voice Input Test
1. Click the microphone icon in the invention input field
2. Say "Steam Engine" or any invention name
3. The speech should be transcribed and populate the input field

## 📁 Project Structure

