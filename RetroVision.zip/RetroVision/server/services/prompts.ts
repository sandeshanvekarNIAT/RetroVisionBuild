export const DECONSTRUCTION_SYSTEM_PROMPT = `You are an expert historian-engineer. For any given invention you will deconstruct it into its fundamental dependencies in a structured JSON format. Always respond with valid JSON only.`;

export function createDeconstructionPrompt(invention: string): string {
  return `Deconstruct the invention: "${invention}"
Return JSON with fields:
{
  "name": "${invention}",
  "core_functions": ["primary function 1", "primary function 2"],
  "materials": ["material 1", "material 2"],
  "enabling_sciences": ["science 1", "science 2"],
  "subsystems": [{ "name": "subsystem name", "dependency": ["dependency 1", "dependency 2"] }],
  "cultural_drivers": ["driver 1", "driver 2"],
  "min_tech_level": ["required technology 1", "required technology 2"]
}`;
}

export const SIMULATION_SYSTEM_PROMPT = `You are a speculative historian and systems engineer. Using decomposition data, imagine alternate invention pathways that could plausibly produce the given invention in the specified era. Always respond with valid JSON only.`;

export function createSimulationPrompt(
  invention: string, 
  era: string, 
  decomposition: any, 
  depth: number
): string {
  return `Using the decomposition JSON below, imagine ${depth} alternate invention pathways that could plausibly produce the invention "${invention}" in the era "${era}".

Decomposition data: ${JSON.stringify(decomposition)}

For each pathway produce:
- Title (creative name for the alternate invention)
- Brief narrative (80-140 words) written as if it actually happened in that era
- Technical steps (bullet list) describing what existing technology/knowledge is combined
- Prototype description (how the device looks, materials, interface)
- Feasibility score 0-10 (0 impossible, 10 very plausible given era)
- Short list of "required breakthroughs" (1-3 items)

Return as JSON: { "pathways": [{"id": "unique_id", "title": "...", "narrative": "...", "technicalSteps": ["step1", "step2"], "prototypeDescription": "...", "feasibilityScore": 7, "requiredBreakthroughs": ["breakthrough1"]}] }`;
}

export function createImagePrompt(invention: string, era: string, pathway: any): string {
  const eraStyles = {
    'ancient': 'ancient civilization, stone and bronze materials, hieroglyphic style',
    'medieval': 'medieval manuscript illumination, parchment and ink, Gothic style',
    'renaissance': 'Leonardo da Vinci technical drawing, Renaissance engineering, detailed schematics',
    'enlightenment': 'Age of Enlightenment scientific illustration, copper engraving style',
    'industrial': 'Industrial Revolution blueprint, mechanical engineering drawings',
    'victorian': 'Victorian era technical blueprint, steampunk aesthetics, brass and mahogany',
    'early-1900s': 'Early 20th century patent drawing, art deco influences'
  };

  const style = eraStyles[era as keyof typeof eraStyles] || 'historical technical drawing';

  return `Create a detailed technical blueprint and schematic of "${pathway.title}" - ${pathway.prototypeDescription}. 
Style: ${style}, highly detailed engineering drawing, cutaway view showing internal mechanisms, 
period-accurate materials and construction methods, neutral background, technical annotations. 
High detail, historically consistent, blueprint style.`;
}

export const NARRATIVE_SYSTEM_PROMPT = `You are a historian writing for an academic publication. Write historically accurate narrative entries about alternate inventions as if they actually existed in the specified time period.`;

export function createNarrativePrompt(invention: string, era: string, pathways: any[]): string {
  return `Write a 250-350 word history book entry describing the discovery and social impact of "${pathways[0]?.title || invention}" as if the alternate invention existed in the "${era}" era. 

Use historically consistent tone and vocabulary for the time period. Focus on:
- The invention's discovery/creation story
- Technical details in period-appropriate terms
- Social and economic impact on society
- How it changed daily life and business practices
- Cultural reception and adoption

Use the following pathway information: ${JSON.stringify(pathways[0])}

Write in the style of a formal historical text with proper period language and academic tone.`;
}
