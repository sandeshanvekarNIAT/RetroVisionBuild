import OpenAI from "openai";
import fs from "fs";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
if (!process.env.OPENAI_API_KEY && !process.env.OPENAI_KEY) {
  throw new Error("OpenAI API key not found. Please set OPENAI_API_KEY in environment variables.");
}

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY
});

export async function callGPT(
  systemPrompt: string, 
  userPrompt: string, 
  temperature = 0.3, 
  maxTokens = 1500,
  responseFormat: "text" | "json" = "text"
): Promise<string> {
  const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt }
  ];

  const params: OpenAI.Chat.Completions.ChatCompletionCreateParams = {
    model: process.env.GPT_MODEL || "gpt-5",
    messages,
    temperature,
    max_tokens: maxTokens
  };

  if (responseFormat === "json") {
    params.response_format = { type: "json_object" };
  }

  const response = await openai.chat.completions.create(params);
  return response.choices[0].message.content || "";
}

export async function generateImage(
  prompt: string, 
  size: "512x512" | "1024x1024" = "1024x1024", 
  n = 1
): Promise<{ url: string; id: string }[]> {
  const response = await openai.images.generate({
    model: process.env.IMAGE_MODEL || "dall-e-3",
    prompt,
    size,
    n,
    quality: "standard",
  });

  return (response.data || []).map((image, index) => ({
    url: image.url || "",
    id: `img_${Date.now()}_${index}`
  }));
}

export async function transcribeAudio(audioBuffer: Buffer, filename: string): Promise<{ text: string }> {
  // Create a temporary file for the audio
  const tempPath = `/tmp/${filename}`;
  fs.writeFileSync(tempPath, audioBuffer);

  try {
    const audioReadStream = fs.createReadStream(tempPath);
    
    const transcription = await openai.audio.transcriptions.create({
      file: audioReadStream,
      model: "whisper-1",
    });

    return {
      text: transcription.text
    };
  } finally {
    // Clean up temporary file
    if (fs.existsSync(tempPath)) {
      fs.unlinkSync(tempPath);
    }
  }
}

export async function moderateContent(text: string): Promise<{ flagged: boolean; categories: string[] }> {
  try {
    const moderation = await openai.moderations.create({
      input: text,
    });

    const result = moderation.results[0];
    const flaggedCategories = Object.entries(result.categories)
      .filter(([_, flagged]) => flagged)
      .map(([category]) => category);

    return {
      flagged: result.flagged,
      categories: flaggedCategories
    };
  } catch (error) {
    console.warn("Moderation failed:", error);
    return { flagged: false, categories: [] };
  }
}
