import NodeCache from "node-cache";
import { GenerationCache } from "@shared/schema";

// In-memory cache with TTL
const cache = new NodeCache({ 
  stdTTL: 3600, // 1 hour default
  checkperiod: 600 // Check for expired keys every 10 minutes
});

export interface CacheOptions {
  ttl?: number; // Time to live in seconds
}

export function generateCacheKey(type: string, params: Record<string, any>): string {
  const sortedParams = Object.keys(params)
    .sort()
    .reduce((result, key) => {
      result[key] = params[key];
      return result;
    }, {} as Record<string, any>);
  
  return `${type}:${JSON.stringify(sortedParams)}`;
}

export function get<T>(key: string): T | undefined {
  return cache.get<T>(key);
}

export function set<T>(key: string, value: T, options?: CacheOptions): boolean {
  const ttl = options?.ttl || 3600; // Default 1 hour
  return cache.set(key, value, ttl);
}

export function del(key: string): number {
  return cache.del(key);
}

export function has(key: string): boolean {
  return cache.has(key);
}

export function flush(): void {
  cache.flushAll();
}

export function getStats() {
  return cache.getStats();
}

// Helper functions for specific cache types
export function getCachedDecomposition(invention: string) {
  const key = generateCacheKey("decomposition", { invention });
  return get(key);
}

export function setCachedDecomposition(invention: string, decomposition: any, options?: CacheOptions) {
  const key = generateCacheKey("decomposition", { invention });
  return set(key, decomposition, options);
}

export function getCachedSimulation(invention: string, era: string, creativity: number, depth: number) {
  const key = generateCacheKey("simulation", { invention, era, creativity, depth });
  return get(key);
}

export function setCachedSimulation(
  invention: string, 
  era: string, 
  creativity: number, 
  depth: number, 
  simulation: any, 
  options?: CacheOptions
) {
  const key = generateCacheKey("simulation", { invention, era, creativity, depth });
  return set(key, simulation, options);
}

export function getCachedImage(prompt: string, style?: string) {
  const key = generateCacheKey("image", { prompt, style });
  return get(key);
}

export function setCachedImage(prompt: string, imageData: any, style?: string, options?: CacheOptions) {
  const key = generateCacheKey("image", { prompt, style });
  return set(key, imageData, options);
}
