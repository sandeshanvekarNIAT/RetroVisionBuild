import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { VoiceInput } from "@/components/VoiceInput";
import { deconstructInvention, simulatePathways, generateImages, generateNarrative } from "@/lib/api";
import type { DecompositionResponse, SimulationResponse, GeneratedImagesResponse } from "@shared/schema";

const formSchema = z.object({
  invention: z.string().min(1, "Please enter an invention"),
  era: z.string().min(1, "Please select an era"),
  creativity: z.number().min(0).max(1),
  depth: z.number().min(1).max(10),
});

type FormData = z.infer<typeof formSchema>;

interface InputFormProps {
  onGenerationStart: () => void;
  onGenerationComplete: (data: any) => void;
  isGenerating: boolean;
}

const exampleInventions = ["Smartphone", "Steam Engine", "Printing Press", "Airplane"];

const eras = [
  { value: "ancient", label: "Ancient Times (Before 500 AD)" },
  { value: "medieval", label: "Medieval Period (500-1500 AD)" },
  { value: "renaissance", label: "Renaissance (1400-1700)" },
  { value: "enlightenment", label: "Age of Enlightenment (1650-1800)" },
  { value: "industrial", label: "Industrial Revolution (1760-1840)" },
  { value: "victorian", label: "Victorian Era (1837-1901)" },
  { value: "early-1900s", label: "Early 20th Century (1900-1950)" },
];

export function InputForm({ onGenerationStart, onGenerationComplete, isGenerating }: InputFormProps) {
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      invention: "",
      era: "",
      creativity: 0.5,
      depth: 5,
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      onGenerationStart();
      setProgress(0);

      try {
        // Step 1: Deconstruct invention
        setProgress(20);
        const decompositionResult = await deconstructInvention({ invention: data.invention });
        
        // Step 2: Simulate pathways
        setProgress(40);
        const simulationResult = await simulatePathways({
          invention: data.invention,
          era: data.era,
          creativity: data.creativity,
          depth: data.depth,
        });

        // Step 3: Generate narrative
        setProgress(60);
        const narrativeResult = await generateNarrative(
          data.invention,
          data.era,
          simulationResult.pathways
        );

        // Step 4: Generate images (optional - user confirmation)
        setProgress(80);
        let images: GeneratedImagesResponse['images'] = [];
        
        if (simulationResult.pathways.length > 0) {
          const firstPathway = simulationResult.pathways[0];
          const imagePrompt = `Create a detailed technical blueprint of "${firstPathway.title}" - ${firstPathway.prototypeDescription}. Victorian era technical drawing, steampunk aesthetics, highly detailed engineering schematic.`;
          
          try {
            const imageResult = await generateImages({ 
              prompt: imagePrompt,
              size: "1024x1024"
            });
            images = imageResult.images;
          } catch (error) {
            console.warn("Image generation failed:", error);
          }
        }

        setProgress(100);

        return {
          invention: data.invention,
          era: data.era,
          decomposition: decompositionResult.decomposition,
          pathways: simulationResult.pathways,
          images,
          narrative: narrativeResult.narrative,
        };
      } catch (error) {
        setProgress(0);
        throw error;
      }
    },
    onSuccess: (data) => {
      onGenerationComplete(data);
      toast({
        title: "Generation Complete!",
        description: "Your alternate history has been generated successfully.",
      });
    },
    onError: (error: any) => {
      console.error("Generation failed:", error);
      
      // Extract user-friendly message from server response
      let userMessage = "An error occurred during generation. Please try again.";
      let title = "Generation Failed";
      
      if (error.message?.includes("429")) {
        title = "AI Quota Exceeded";
        userMessage = "OpenAI API quota has been exceeded. Please try again later or check your OpenAI account.";
      } else if (error.message?.includes("401")) {
        title = "Configuration Error";
        userMessage = "AI service authentication failed. Please check your OpenAI API key configuration.";
      } else if (error.message?.includes("userMessage")) {
        try {
          const parsed = JSON.parse(error.message);
          userMessage = parsed.userMessage || userMessage;
        } catch {
          // Keep default message if parsing fails
        }
      }
      
      toast({
        title,
        description: userMessage,
        variant: "destructive",
      });
      setProgress(0);
    },
  });

  const onSubmit = (data: FormData) => {
    generateMutation.mutate(data);
  };

  const handleExampleClick = (invention: string) => {
    form.setValue("invention", invention);
  };

  const handleVoiceInput = (text: string) => {
    form.setValue("invention", text);
  };

  return (
    <section className="vintage-card rounded-lg p-8 ornate-border">
      <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
        <i className="fas fa-lightbulb text-brass mr-3"></i>
        Invention Laboratory
      </h3>
      
      {/* Quick Examples */}
      <div className="mb-6">
        <p className="text-sm text-muted-foreground mb-3">Quick Examples:</p>
        <div className="flex flex-wrap gap-2">
          {exampleInventions.map((invention) => (
            <Button
              key={invention}
              variant="outline"
              size="sm"
              onClick={() => handleExampleClick(invention)}
              className="px-3 py-1 bg-brass/20 text-brass text-sm border-brass hover:bg-brass hover:text-brass-foreground"
              data-testid={`example-${invention.toLowerCase()}`}
            >
              {invention}
            </Button>
          ))}
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Invention Input */}
        <div>
          <Label className="text-sm font-semibold text-foreground mb-2 flex items-center">
            <i className="fas fa-hammer mr-2 text-brass"></i>Invention Name
          </Label>
          <div className="relative">
            <Input
              {...form.register("invention")}
              placeholder="Enter an invention (e.g., Smartphone, Telegraph, Camera)"
              className="w-full px-4 py-3 bg-parchment border-2 border-brass rounded-lg focus:border-copper focus:ring-2 focus:ring-copper/20 text-foreground placeholder-muted-foreground font-medium"
              data-testid="input-invention"
            />
            <div className="absolute right-3 top-3">
              <VoiceInput onTranscription={handleVoiceInput} />
            </div>
          </div>
          {form.formState.errors.invention && (
            <p className="text-sm text-destructive mt-1">{form.formState.errors.invention.message}</p>
          )}
        </div>

        {/* Target Era */}
        <div>
          <Label className="text-sm font-semibold text-foreground mb-2 flex items-center">
            <i className="fas fa-calendar-alt mr-2 text-brass"></i>Target Historical Era
          </Label>
          <Select onValueChange={(value) => form.setValue("era", value)}>
            <SelectTrigger className="w-full px-4 py-3 bg-parchment border-2 border-brass rounded-lg focus:border-copper focus:ring-2 focus:ring-copper/20 text-foreground font-medium" data-testid="select-era">
              <SelectValue placeholder="Select an era..." />
            </SelectTrigger>
            <SelectContent>
              {eras.map((era) => (
                <SelectItem key={era.value} value={era.value}>
                  {era.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.era && (
            <p className="text-sm text-destructive mt-1">{form.formState.errors.era.message}</p>
          )}
        </div>

        {/* Creativity Slider */}
        <div>
          <Label className="text-sm font-semibold text-foreground mb-2 flex items-center justify-between">
            <span>
              <i className="fas fa-magic mr-2 text-brass"></i>Creativity Level
            </span>
            <span className="text-xs text-muted-foreground">Conservative ← → Imaginative</span>
          </Label>
          <div className="px-2">
            <Slider
              value={[form.watch("creativity")]}
              onValueChange={(value) => form.setValue("creativity", value[0])}
              max={1}
              min={0}
              step={0.1}
              className="w-full"
              data-testid="slider-creativity"
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Historically Plausible</span>
            <span>Wildly Creative</span>
          </div>
        </div>

        {/* Depth Control */}
        <div>
          <Label className="text-sm font-semibold text-foreground mb-2 flex items-center">
            <i className="fas fa-layer-group mr-2 text-brass"></i>Analysis Depth
          </Label>
          <Select onValueChange={(value) => form.setValue("depth", parseInt(value))}>
            <SelectTrigger className="w-full px-4 py-3 bg-parchment border-2 border-brass rounded-lg focus:border-copper focus:ring-2 focus:ring-copper/20 text-foreground font-medium" data-testid="select-depth">
              <SelectValue placeholder="Select analysis depth..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3">Standard (3 pathways)</SelectItem>
              <SelectItem value="5">Comprehensive (5 pathways)</SelectItem>
              <SelectItem value="7">Extensive (7 pathways)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Generate Button */}
        <Button
          type="submit"
          disabled={isGenerating}
          className="w-full steampunk-button text-brass-foreground font-bold py-4 px-6 rounded-lg text-lg font-serif"
          data-testid="button-generate"
        >
          {isGenerating ? (
            <>
              <i className="fas fa-cogs mr-2 gear-animation"></i>
              Generating...
            </>
          ) : (
            <>
              <i className="fas fa-cogs mr-2"></i>
              Generate Alternate History
            </>
          )}
        </Button>
      </form>

      {/* Loading State */}
      {isGenerating && (
        <div className="mt-6 p-4 bg-brass/10 border border-brass rounded-lg" data-testid="loading-state">
          <div className="flex items-center space-x-3">
            <i className="fas fa-cogs text-brass text-xl gear-animation"></i>
            <div>
              <p className="font-semibold text-foreground">Analyzing Historical Possibilities...</p>
              <p className="text-sm text-muted-foreground">This may take 30-60 seconds</p>
            </div>
          </div>
          <div className="mt-3">
            <Progress value={progress} className="w-full" data-testid="progress-bar" />
          </div>
        </div>
      )}
    </section>
  );
}
