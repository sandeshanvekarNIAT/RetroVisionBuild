import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { generateImages } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface GeneratedImage {
  id: string;
  url: string;
  title: string;
  description: string;
}

interface GeneratedImagesProps {
  images: GeneratedImage[];
}

export function GeneratedImages({ images: initialImages }: GeneratedImagesProps) {
  const [images, setImages] = useState<GeneratedImage[]>(initialImages);
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);
  const { toast } = useToast();

  const generateMoreMutation = useMutation({
    mutationFn: async () => {
      const prompt = "Create a detailed technical blueprint of a Victorian-era steampunk invention with brass components, mechanical gears, and ornate Victorian styling. Historical technical drawing, cutaway view, period-accurate materials.";
      return generateImages({ prompt, size: "1024x1024" });
    },
    onSuccess: (data) => {
      setImages(prev => [...prev, ...data.images]);
      toast({
        title: "New Images Generated",
        description: `${data.images.length} new visualization(s) have been created.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Image Generation Failed",
        description: error.message || "Could not generate additional images.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="vintage-card rounded-lg p-8" data-testid="generated-images">
      <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
        <i className="fas fa-image mr-3 text-brass"></i>
        Historical Prototype Visualizations
      </h3>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((image, index) => (
          <div key={image.id} className="vintage-card p-4 border border-brass/50" data-testid={`image-card-${index}`}>
            <Dialog>
              <DialogTrigger asChild>
                <div className="overflow-hidden rounded border-2 border-brass mb-4 cursor-pointer">
                  <img
                    src={image.url}
                    alt={image.title}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                    data-testid={`image-${index}`}
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300";
                    }}
                  />
                </div>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>{image.title}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <img
                    src={image.url}
                    alt={image.title}
                    className="w-full max-h-96 object-contain rounded border-2 border-brass"
                  />
                  <p className="text-sm text-muted-foreground">{image.description}</p>
                </div>
              </DialogContent>
            </Dialog>
            
            <h4 className="font-semibold text-foreground mb-2" data-testid={`image-title-${index}`}>
              {image.title}
            </h4>
            <p className="text-xs text-muted-foreground" data-testid={`image-description-${index}`}>
              {image.description}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-6 text-center">
        <Button
          onClick={() => generateMoreMutation.mutate()}
          disabled={generateMoreMutation.isPending}
          className="steampunk-button text-brass-foreground py-2 px-6 rounded font-medium"
          data-testid="button-generate-more-images"
        >
          {generateMoreMutation.isPending ? (
            <>
              <i className="fas fa-spinner animate-spin mr-2"></i>
              Generating...
            </>
          ) : (
            <>
              <i className="fas fa-plus-circle mr-2"></i>
              Generate More Images
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
