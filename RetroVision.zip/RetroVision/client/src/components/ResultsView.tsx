import { DecompositionCard } from "@/components/DecompositionCard";
import { TimelineSimulations } from "@/components/TimelineSimulations";
import { GeneratedImages } from "@/components/GeneratedImages";
import { HistoricalNarrative } from "@/components/HistoricalNarrative";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { exportToPDF, exportToPPTX } from "@/lib/api";
import type { ExportRequest } from "@shared/schema";

interface ResultsViewProps {
  results: {
    invention: string;
    era: string;
    decomposition?: any;
    pathways?: any[];
    images?: any[];
    narrative?: string;
  };
}

export function ResultsView({ results }: ResultsViewProps) {
  const { toast } = useToast();

  const handleExport = async (format: 'pdf' | 'pptx') => {
    try {
      const exportData: ExportRequest = {
        title: `${results.invention} - Alternate History Analysis`,
        sections: [
          {
            id: "decomposition",
            title: "Invention Deconstruction",
            content: results.decomposition ? JSON.stringify(results.decomposition, null, 2) : "No decomposition data"
          },
          {
            id: "pathways",
            title: "Alternate Pathways",
            content: results.pathways ? 
              results.pathways.map(p => `${p.title}: ${p.narrative}`).join('\n\n') : 
              "No pathways data"
          },
          {
            id: "narrative",
            title: "Historical Chronicle",
            content: results.narrative || "No narrative available"
          }
        ],
        images: results.images || []
      };

      let blob: Blob;
      let filename: string;

      if (format === 'pdf') {
        blob = await exportToPDF(exportData);
        filename = `${results.invention}-analysis.pdf`;
      } else {
        blob = await exportToPPTX(exportData);
        filename = `${results.invention}-analysis.pptx`;
      }

      // Download the file
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `Your analysis has been exported as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      console.error("Export failed:", error);
      toast({
        title: "Export Failed",
        description: "Could not export the analysis. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <section className="space-y-8" data-testid="results-view">
      {/* Header with Export Controls */}
      <div className="vintage-card rounded-lg p-8 ornate-border">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-serif font-bold text-foreground flex items-center">
            <i className="fas fa-history mr-3 text-brass"></i>
            {results.invention} - Alternate History Results
          </h2>

          <div className="flex space-x-3">
            <Button
              onClick={() => handleExport('pdf')}
              className="steampunk-button text-brass-foreground py-2 px-4 rounded font-medium"
              data-testid="button-export-pdf"
            >
              <i className="fas fa-file-pdf mr-2"></i>Export PDF
            </Button>
            <Button
              onClick={() => handleExport('pptx')}
              className="steampunk-button text-brass-foreground py-2 px-4 rounded font-medium"
              data-testid="button-export-pptx"
            >
              <i className="fas fa-file-powerpoint mr-2"></i>Export PPTX
            </Button>
          </div>
        </div>
      </div>

      {/* Decomposition Results */}
      {results.decomposition && (
        <DecompositionCard decomposition={results.decomposition} />
      )}

      {/* Timeline Simulations */}
      {results.pathways && results.pathways.length > 0 && (
        <TimelineSimulations pathways={results.pathways} />
      )}

      {/* Generated Images */}
      {results.images && results.images.length > 0 && (
        <GeneratedImages images={results.images} />
      )}

      {/* Historical Narrative */}
      {results.narrative && (
        <HistoricalNarrative 
          narrative={results.narrative} 
          invention={results.invention}
          era={results.era}
        />
      )}
    </section>
  );
}
