interface DecompositionCardProps {
  decomposition: {
    name: string;
    core_functions: string[];
    materials: string[];
    enabling_sciences: string[];
    subsystems: Array<{
      name: string;
      dependency: string[];
    }>;
    cultural_drivers: string[];
    min_tech_level: string[];
  };
}

export function DecompositionCard({ decomposition }: DecompositionCardProps) {
  return (
    <div className="vintage-card rounded-lg p-8" data-testid="decomposition-card">
      <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
        <i className="fas fa-microscope mr-3 text-brass"></i>
        Invention Deconstruction
      </h3>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          {/* Core Functions */}
          <div className="p-4 bg-parchment-light border border-brass/50 rounded">
            <h4 className="font-semibold text-foreground mb-2 flex items-center">
              <i className="fas fa-cog text-brass mr-2"></i>Core Functions
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {decomposition.core_functions.map((func, index) => (
                <li key={index} data-testid={`core-function-${index}`}>• {func}</li>
              ))}
            </ul>
          </div>

          {/* Required Materials */}
          <div className="p-4 bg-parchment-light border border-brass/50 rounded">
            <h4 className="font-semibold text-foreground mb-2 flex items-center">
              <i className="fas fa-flask text-brass mr-2"></i>Required Materials
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {decomposition.materials.map((material, index) => (
                <li key={index} data-testid={`material-${index}`}>• {material}</li>
              ))}
            </ul>
          </div>

          {/* Subsystems */}
          {decomposition.subsystems && decomposition.subsystems.length > 0 && (
            <div className="p-4 bg-parchment-light border border-brass/50 rounded">
              <h4 className="font-semibold text-foreground mb-2 flex items-center">
                <i className="fas fa-puzzle-piece text-brass mr-2"></i>Key Subsystems
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                {decomposition.subsystems.map((subsystem, index) => (
                  <li key={index} data-testid={`subsystem-${index}`}>
                    <strong>{subsystem.name}</strong>: {subsystem.dependency.join(", ")}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="space-y-4">
          {/* Enabling Sciences */}
          <div className="p-4 bg-parchment-light border border-brass/50 rounded">
            <h4 className="font-semibold text-foreground mb-2 flex items-center">
              <i className="fas fa-atom text-brass mr-2"></i>Enabling Sciences
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {decomposition.enabling_sciences.map((science, index) => (
                <li key={index} data-testid={`science-${index}`}>• {science}</li>
              ))}
            </ul>
          </div>

          {/* Cultural Drivers */}
          <div className="p-4 bg-parchment-light border border-brass/50 rounded">
            <h4 className="font-semibold text-foreground mb-2 flex items-center">
              <i className="fas fa-users text-brass mr-2"></i>Cultural Drivers
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {decomposition.cultural_drivers.map((driver, index) => (
                <li key={index} data-testid={`driver-${index}`}>• {driver}</li>
              ))}
            </ul>
          </div>

          {/* Minimum Technology Level */}
          <div className="p-4 bg-parchment-light border border-brass/50 rounded">
            <h4 className="font-semibold text-foreground mb-2 flex items-center">
              <i className="fas fa-tools text-brass mr-2"></i>Prerequisite Technologies
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {decomposition.min_tech_level.map((tech, index) => (
                <li key={index} data-testid={`tech-${index}`}>• {tech}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
