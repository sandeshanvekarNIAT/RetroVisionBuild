import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface Pathway {
  id: string;
  title: string;
  narrative: string;
  technicalSteps: string[];
  prototypeDescription: string;
  feasibilityScore: number;
  requiredBreakthroughs: string[];
}

interface TimelineSimulationsProps {
  pathways: Pathway[];
}

export function TimelineSimulations({ pathways }: TimelineSimulationsProps) {
  const [expandedPathways, setExpandedPathways] = useState<Set<string>>(new Set());

  const togglePathway = (pathwayId: string) => {
    const newExpanded = new Set(expandedPathways);
    if (newExpanded.has(pathwayId)) {
      newExpanded.delete(pathwayId);
    } else {
      newExpanded.add(pathwayId);
    }
    setExpandedPathways(newExpanded);
  };

  const renderStars = (score: number) => {
    const fullStars = Math.floor(score);
    const emptyStars = 10 - fullStars;
    
    return (
      <div className="flex space-x-1">
        {Array(fullStars).fill(0).map((_, i) => (
          <i key={`full-${i}`} className="fas fa-star text-brass text-xs"></i>
        ))}
        {Array(emptyStars).fill(0).map((_, i) => (
          <i key={`empty-${i}`} className="far fa-star text-brass/30 text-xs"></i>
        ))}
      </div>
    );
  };

  return (
    <div className="vintage-card rounded-lg p-8" data-testid="timeline-simulations">
      <h3 className="text-2xl font-serif font-bold text-foreground mb-6 flex items-center">
        <i className="fas fa-route mr-3 text-brass"></i>
        Alternate Invention Pathways
      </h3>

      <div className="space-y-6">
        {pathways.map((pathway, index) => (
          <div key={pathway.id} className="vintage-card p-6 border border-brass/50" data-testid={`pathway-${index}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h4 className="text-xl font-serif font-semibold text-foreground mb-2" data-testid={`pathway-title-${index}`}>
                  {pathway.title}
                </h4>
                <p className="text-sm text-muted-foreground" data-testid={`pathway-narrative-${index}`}>
                  {pathway.narrative}
                </p>
              </div>
              <div className="ml-4 text-right">
                <div className="flex items-center space-x-1 mb-1">
                  <span className="text-sm text-muted-foreground">Feasibility:</span>
                  {renderStars(pathway.feasibilityScore)}
                </div>
                <span className="text-xs text-brass font-medium" data-testid={`pathway-score-${index}`}>
                  {pathway.feasibilityScore}/10
                </span>
              </div>
            </div>

            <Collapsible open={expandedPathways.has(pathway.id)} onOpenChange={() => togglePathway(pathway.id)}>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className="text-brass hover:text-copper text-sm font-medium transition-colors duration-200 p-0"
                  data-testid={`pathway-toggle-${index}`}
                >
                  <i className={`fas ${expandedPathways.has(pathway.id) ? 'fa-compress' : 'fa-expand'} mr-1`}></i>
                  {expandedPathways.has(pathway.id) ? 'Show Less' : 'View Details'}
                </Button>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="mt-4 space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Technical Steps */}
                  <div>
                    <h5 className="font-medium text-foreground mb-2">Technical Steps:</h5>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {pathway.technicalSteps.map((step, stepIndex) => (
                        <li key={stepIndex} data-testid={`pathway-${index}-step-${stepIndex}`}>• {step}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Required Breakthroughs */}
                  <div>
                    <h5 className="font-medium text-foreground mb-2">Required Breakthroughs:</h5>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {pathway.requiredBreakthroughs.map((breakthrough, btIndex) => (
                        <li key={btIndex} data-testid={`pathway-${index}-breakthrough-${btIndex}`}>• {breakthrough}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Prototype Description */}
                <div className="p-4 bg-parchment-dark/50 rounded border border-brass/30">
                  <h5 className="font-medium text-foreground mb-2">Prototype Description:</h5>
                  <p className="text-sm text-muted-foreground italic" data-testid={`pathway-${index}-prototype`}>
                    {pathway.prototypeDescription}
                  </p>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        ))}
      </div>
    </div>
  );
}
