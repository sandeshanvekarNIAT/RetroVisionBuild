import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, json, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const inventions = pgTable("inventions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  era: text("era").notNull(),
  creativity: real("creativity").notNull(),
  depth: integer("depth").notNull(),
  decomposition: json("decomposition"),
  pathways: json("pathways"),
  images: json("images"),
  narrative: text("narrative"),
  createdAt: timestamp("created_at").defaultNow(),
  userId: varchar("user_id").references(() => users.id),
});

export const generationCache = pgTable("generation_cache", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cacheKey: text("cache_key").notNull().unique(),
  response: json("response").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const apiUsage = pgTable("api_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  endpoint: text("endpoint").notNull(),
  tokensUsed: integer("tokens_used"),
  cost: real("cost"),
  success: boolean("success").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertInventionSchema = createInsertSchema(inventions).pick({
  name: true,
  era: true,
  creativity: true,
  depth: true,
});

export const deconstructRequestSchema = z.object({
  invention: z.string().min(1).max(100),
});

export const simulateRequestSchema = z.object({
  invention: z.string().min(1).max(100),
  era: z.string().min(1).max(50),
  depth: z.number().min(1).max(10),
  creativity: z.number().min(0).max(1),
});

export const generateImageRequestSchema = z.object({
  prompt: z.string().min(1).max(1000),
  style: z.string().optional(),
  size: z.enum(["512x512", "1024x1024"]).default("1024x1024"),
});

export const transcribeRequestSchema = z.object({
  audioFile: z.any(), // Will be handled by multer
});

export const exportRequestSchema = z.object({
  title: z.string().min(1),
  sections: z.array(z.object({
    id: z.string(),
    title: z.string(),
    content: z.string(),
  })),
  images: z.array(z.object({
    id: z.string(),
    url: z.string(),
    title: z.string(),
    description: z.string(),
  })),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertInvention = z.infer<typeof insertInventionSchema>;
export type Invention = typeof inventions.$inferSelect;
export type GenerationCache = typeof generationCache.$inferSelect;
export type ApiUsage = typeof apiUsage.$inferSelect;
export type DeconstructRequest = z.infer<typeof deconstructRequestSchema>;
export type SimulateRequest = z.infer<typeof simulateRequestSchema>;
export type GenerateImageRequest = z.infer<typeof generateImageRequestSchema>;
export type ExportRequest = z.infer<typeof exportRequestSchema>;

// Response types
export interface DecompositionResponse {
  name: string;
  core_functions: string[];
  materials: string[];
  enabling_sciences: string[];
  subsystems: Array<{
    name: string;
    dependency: string[];
  }>;
  cultural_drivers: string[];
  min_tech_level: string[];
}

export interface PathwayResponse {
  id: string;
  title: string;
  narrative: string;
  technicalSteps: string[];
  prototypeDescription: string;
  feasibilityScore: number;
  requiredBreakthroughs: string[];
}

export interface SimulationResponse {
  pathways: PathwayResponse[];
}

export interface ImageResponse {
  id: string;
  url: string;
  title: string;
  description: string;
}

export interface GeneratedImagesResponse {
  images: ImageResponse[];
}
