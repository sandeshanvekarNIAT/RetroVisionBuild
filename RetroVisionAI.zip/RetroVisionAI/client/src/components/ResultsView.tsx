import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { GenerationResult } from "@/types";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface ResultsViewProps {
  data: GenerationResult;
  isLoading: boolean;
}

export default function ResultsView({ data, isLoading }: ResultsViewProps) {
  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: api.exportInvention,
    onSuccess: (blob, variables) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `${data.invention.name.replace(/\s+/g, '_')}_dossier.${variables.format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export Successful",
        description: `Your ${variables.format.toUpperCase()} has been downloaded.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleExport = (format: 'pdf' | 'pptx') => {
    exportMutation.mutate({
      inventionId: data.invention.id,
      format,
    });
  };

  if (isLoading) {
    return (
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Skeleton className="h-8 w-64 mx-auto mb-4" />
            <Skeleton className="h-4 w-96 mx-auto" />
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="parchment-card vintage-border">
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-32 mb-4" />
                  <Skeleton className="h-40 w-full mb-3" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  const { invention, eraDateRange } = data;
  const dependencies = invention.dependencies || {};

  return (
    <section className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Historical Analysis Results</h2>
          <div className="ornate-divider mb-6 max-w-md mx-auto"></div>
          <div className="inline-flex items-center bg-accent/20 text-accent px-4 py-2 rounded-full">
            <i className="fas fa-lightbulb mr-2"></i>
            <span className="font-semibold">{invention.name}</span>
            <span className="mx-2">•</span>
            <span>{invention.era} Era ({eraDateRange})</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Dependencies Card */}
          <Card className="parchment-card vintage-border" data-testid="card-dependencies">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <i className="fas fa-sitemap text-accent text-lg mr-3"></i>
                <h3 className="font-serif font-semibold text-lg">Core Dependencies</h3>
              </div>
              <div className="space-y-3">
                {dependencies.materials && (
                  <div className="text-sm">
                    <span className="font-semibold">Materials:</span>
                    <ul className="mt-1 space-y-1">
                      {dependencies.materials.map((material: string, index: number) => (
                        <li key={index} className="flex items-center">
                          <span className="w-2 h-2 bg-accent rounded-full mr-2"></span>
                          {material}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {dependencies.energy && (
                  <div className="text-sm">
                    <span className="font-semibold">Energy Source:</span>
                    <p className="mt-1 text-muted-foreground">{dependencies.energy}</p>
                  </div>
                )}

                {dependencies.manufacturing && (
                  <div className="text-sm">
                    <span className="font-semibold">Manufacturing:</span>
                    <p className="mt-1 text-muted-foreground">{dependencies.manufacturing}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Prototype Design */}
          <Card className="parchment-card vintage-border" data-testid="card-prototype">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <i className="fas fa-drafting-compass text-accent text-lg mr-3"></i>
                <h3 className="font-serif font-semibold text-lg">Prototype Design</h3>
              </div>
              {invention.imageUrl ? (
                <img 
                  src={invention.imageUrl} 
                  alt={`${invention.name} prototype`}
                  className="w-full h-40 object-cover rounded-lg mb-3 blueprint-bg"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-full h-40 bg-muted rounded-lg mb-3 blueprint-bg flex items-center justify-center">
                  <i className="fas fa-image text-muted-foreground text-2xl"></i>
                </div>
              )}
              <div className="space-y-2 text-sm">
                <div><strong>Era:</strong> {invention.era} style design</div>
                <div><strong>Approach:</strong> Creativity level {invention.creativity}/10</div>
                {dependencies.challenges && (
                  <div>
                    <strong>Key Challenges:</strong>
                    <ul className="mt-1 text-muted-foreground">
                      {dependencies.challenges.slice(0, 2).map((challenge: string, index: number) => (
                        <li key={index}>• {challenge}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Timeline Simulation */}
          <Card className="parchment-card vintage-border" data-testid="card-timeline">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <i className="fas fa-clock text-accent text-lg mr-3"></i>
                <h3 className="font-serif font-semibold text-lg">Development Timeline</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-xs font-bold text-accent-foreground mr-3">1</div>
                  <div className="text-sm">
                    <div className="font-semibold">Initial Concept</div>
                    <div className="text-muted-foreground text-xs">Early experimentation phase</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-xs font-bold text-primary-foreground mr-3">2</div>
                  <div className="text-sm">
                    <div className="font-semibold">Development</div>
                    <div className="text-muted-foreground text-xs">Refinement and improvements</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-xs font-bold mr-3">3</div>
                  <div className="text-sm">
                    <div className="font-semibold">Adoption</div>
                    <div className="text-muted-foreground text-xs">Social integration and use</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Historical Narrative */}
        {invention.narrative && (
          <Card className="mt-8 parchment-card vintage-border" data-testid="card-narrative">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <i className="fas fa-scroll text-accent text-xl mr-3"></i>
                <h3 className="font-serif font-bold text-xl">Historical Archive Entry</h3>
              </div>
              <div className="prose prose-lg max-w-none">
                <div className="bg-muted/30 rounded-lg p-6 border-l-4 border-accent italic">
                  <div className="text-foreground leading-relaxed whitespace-pre-line">
                    {invention.narrative}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Export Options */}
        <div className="mt-8 text-center space-y-4">
          <h3 className="font-serif font-semibold text-lg text-foreground mb-4">Download Historical Dossier</h3>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => handleExport('pdf')}
              className="steampunk-button text-primary-foreground px-6 py-3 rounded-lg font-semibold"
              disabled={exportMutation.isPending}
              data-testid="button-export-pdf"
            >
              <i className="fas fa-file-pdf mr-2"></i>
              {exportMutation.isPending ? 'Generating...' : 'Download PDF'}
            </Button>
            <Button 
              onClick={() => handleExport('pptx')}
              variant="outline"
              className="vintage-border bg-secondary text-secondary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-accent hover:text-accent-foreground transition-colors"
              disabled={exportMutation.isPending}
              data-testid="button-export-pptx"
            >
              <i className="fas fa-file-powerpoint mr-2"></i>
              {exportMutation.isPending ? 'Generating...' : 'Download PPTX'}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
