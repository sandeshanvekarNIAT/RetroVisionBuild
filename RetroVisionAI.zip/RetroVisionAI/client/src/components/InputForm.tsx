import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { generateInventionSchema } from "@shared/schema";
import { api } from "@/lib/api";
import { ERAS, INVENTION_SUGGESTIONS } from "@/types";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

export default function InputForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedEra, setSelectedEra] = useState<string>("medieval");
  const [creativity, setCreativity] = useState([5]);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const form = useForm({
    resolver: zodResolver(generateInventionSchema),
    defaultValues: {
      invention: "",
      era: "medieval" as const,
      creativity: 5,
    },
  });

  const generateMutation = useMutation({
    mutationFn: api.generateInvention,
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: "Your historical invention has been generated.",
      });
      setLocation(`/results/${data.invention.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate invention. Please try again.",
        variant: "destructive",
      });
    },
  });

  const transcribeMutation = useMutation({
    mutationFn: api.transcribeAudio,
    onSuccess: (data) => {
      form.setValue("invention", data.transcription);
      toast({
        title: "Audio Transcribed",
        description: "Your voice input has been converted to text.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Transcription Failed",
        description: error.message || "Failed to transcribe audio. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    generateMutation.mutate(data);
  };

  const handleEraSelect = (era: string) => {
    setSelectedEra(era);
    form.setValue("era", era as any);
  };

  const handleSuggestionClick = (suggestion: string) => {
    form.setValue("invention", suggestion);
  };

  const getCreativityLabel = (value: number) => {
    if (value <= 3) return "Realistic approach - historically accurate with minimal creative interpretation";
    if (value <= 7) return "Balanced approach - realistic with creative elements";
    return "Imaginative approach - creative and speculative historical possibilities";
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const arrayBuffer = await audioBlob.arrayBuffer();
        const base64 = btoa(String.fromCharCode(...Array.from(new Uint8Array(arrayBuffer))));
        
        transcribeMutation.mutate({ audio: base64 });
        
        // Clean up
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      toast({
        title: "Recording Error",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <section id="explore" className="py-16 px-4 bg-muted/30">
      <div className="max-w-4xl mx-auto">
        <Card className="parchment-card vintage-border">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Create Your Historical Invention</h2>
              <div className="ornate-divider mb-6 max-w-md mx-auto"></div>
              <p className="text-muted-foreground">Enter a modern invention and select a historical era to see how it might have been created using the technology and materials of that time.</p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Invention Input */}
                <FormField
                  control={form.control}
                  name="invention"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-foreground mb-3">
                        <i className="fas fa-lightbulb text-accent mr-2"></i>
                        What invention would you like to reimagine?
                      </FormLabel>
                      <FormControl>
                        <Input 
                          {...field}
                          placeholder="e.g., Smartphone, Computer, Electric Car..."
                          className="w-full px-4 py-3 border border-border rounded-lg bg-input text-foreground placeholder:text-muted-foreground focus:ring-2 focus:ring-ring focus:border-transparent transition-colors"
                          data-testid="input-invention"
                        />
                      </FormControl>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {INVENTION_SUGGESTIONS.map((suggestion) => (
                          <Badge 
                            key={suggestion.name}
                            variant="secondary"
                            className="cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                            onClick={() => handleSuggestionClick(suggestion.name)}
                            data-testid={`suggestion-${suggestion.name.toLowerCase()}`}
                          >
                            {suggestion.name}
                          </Badge>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Era Selection */}
                <FormField
                  control={form.control}
                  name="era"
                  render={() => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-foreground mb-3">
                        <i className="fas fa-hourglass-half text-accent mr-2"></i>
                        Choose Historical Era
                      </FormLabel>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {ERAS.map((era) => (
                          <Card 
                            key={era.id}
                            className={`vintage-border cursor-pointer hover:bg-accent/10 transition-colors ${
                              selectedEra === era.id ? 'bg-accent/20' : ''
                            }`}
                            onClick={() => handleEraSelect(era.id)}
                            data-testid={`era-${era.id}`}
                          >
                            <CardContent className="p-3">
                              <div className="text-center">
                                <i className={`fas fa-${era.icon} text-accent text-lg mb-2`}></i>
                                <div className="font-semibold text-sm">{era.name}</div>
                                <div className="text-xs text-muted-foreground">{era.period}</div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </FormItem>
                  )}
                />

                {/* Creativity Slider */}
                <FormField
                  control={form.control}
                  name="creativity"
                  render={() => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-foreground mb-3">
                        <i className="fas fa-magic text-accent mr-2"></i>
                        Creativity Level
                      </FormLabel>
                      <div className="space-y-3">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Realistic</span>
                          <span>Balanced</span>
                          <span>Imaginative</span>
                        </div>
                        <Slider
                          value={creativity}
                          onValueChange={(value) => {
                            setCreativity(value);
                            form.setValue("creativity", value[0]);
                          }}
                          max={10}
                          min={1}
                          step={1}
                          className="w-full"
                          data-testid="slider-creativity"
                        />
                        <div className="text-center text-sm text-muted-foreground">
                          <span>{getCreativityLabel(creativity[0])}</span>
                        </div>
                      </div>
                    </FormItem>
                  )}
                />

                {/* Voice Input Option */}
                <Card className="bg-muted/50 border border-dashed border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-semibold text-foreground mb-1">Voice Input</div>
                        <div className="text-xs text-muted-foreground">Speak your invention idea instead of typing</div>
                      </div>
                      <Button 
                        type="button"
                        variant="outline"
                        className="vintage-border bg-card px-4 py-2 rounded-lg hover:bg-accent/10 transition-colors"
                        onClick={isRecording ? stopRecording : startRecording}
                        disabled={transcribeMutation.isPending}
                        data-testid="button-voice-input"
                      >
                        <i className={`fas fa-${isRecording ? 'stop' : 'microphone'} text-accent mr-2`}></i>
                        <span className="text-sm">
                          {isRecording ? 'Stop' : transcribeMutation.isPending ? 'Processing...' : 'Record'}
                        </span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Submit Button */}
                <div className="text-center pt-4">
                  <Button 
                    type="submit" 
                    className="steampunk-button text-primary-foreground px-12 py-4 rounded-lg font-bold text-lg w-full sm:w-auto"
                    disabled={generateMutation.isPending}
                    data-testid="button-generate"
                  >
                    <i className="fas fa-cogs mr-3"></i>
                    {generateMutation.isPending ? 'Generating...' : 'Generate Historical Invention'}
                  </Button>
                  <p className="text-xs text-muted-foreground mt-3">Processing typically takes 30-60 seconds</p>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
