import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  onStartExploring: () => void;
  onViewExamples: () => void;
}

export default function HeroSection({ onStartExploring, onViewExamples }: HeroSectionProps) {
  return (
    <section className="relative py-20 px-4 overflow-hidden">
      <div className="max-w-6xl mx-auto text-center relative z-10">
        <div className="ornate-divider mb-8"></div>
        <h1 className="font-serif text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
          Reimagine History's
          <span className="text-accent block">Greatest Inventions</span>
        </h1>
        <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
          Journey through time and discover how modern inventions might have emerged in bygone eras. 
          From Victorian smartphones to Medieval computers, explore alternate histories with AI-powered imagination.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={onStartExploring}
            className="steampunk-button text-primary-foreground px-8 py-3 rounded-lg font-semibold text-lg"
            data-testid="button-start-exploring"
          >
            <i className="fas fa-compass mr-2"></i>Start Exploring
          </Button>
          <Button 
            onClick={onViewExamples}
            variant="outline"
            className="vintage-border bg-secondary text-secondary-foreground px-8 py-3 rounded-lg font-semibold text-lg hover:bg-accent hover:text-accent-foreground transition-colors"
            data-testid="button-view-examples"
          >
            <i className="fas fa-book-open mr-2"></i>View Examples
          </Button>
        </div>
      </div>
    </section>
  );
}
