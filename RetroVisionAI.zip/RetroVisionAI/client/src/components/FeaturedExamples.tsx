import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function FeaturedExamples() {
  const { data: examples, isLoading } = useQuery({
    queryKey: ["/api/examples"],
    queryFn: () => api.getExamples(),
  });

  if (isLoading) {
    return (
      <section id="examples" className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Featured Reimaginations</h2>
            <div className="ornate-divider mb-6 max-w-md mx-auto"></div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="parchment-card vintage-border">
                <CardContent className="p-6">
                  <Skeleton className="w-full h-48 mb-4 rounded-lg" />
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="examples" className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Featured Reimaginations</h2>
          <div className="ornate-divider mb-6 max-w-md mx-auto"></div>
          <p className="text-muted-foreground text-lg">Discover how iconic modern inventions might have evolved in different historical periods</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {examples?.map((example: any) => (
            <Card key={example.id} className="parchment-card vintage-border hover:shadow-lg transition-shadow" data-testid={`card-example-${example.id}`}>
              <CardContent className="p-6">
                {example.imageUrl && (
                  <img 
                    src={example.imageUrl} 
                    alt={example.name}
                    className="w-full h-48 object-cover rounded-lg mb-4" 
                  />
                )}
                <div className="flex items-center mb-3">
                  <i className="fas fa-mobile-alt text-accent text-lg mr-3"></i>
                  <span className="font-serif font-semibold text-lg">{example.name}</span>
                </div>
                <p className="text-muted-foreground text-sm mb-4">
                  {example.description}
                </p>
                <div className="flex justify-between items-center">
                  <Badge variant="secondary" className="text-xs bg-accent/20 text-accent">
                    {example.era}
                  </Badge>
                  <Button 
                    variant="link" 
                    className="text-primary hover:text-accent text-sm font-medium p-0"
                    data-testid={`button-view-details-${example.id}`}
                  >
                    View Details →
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
