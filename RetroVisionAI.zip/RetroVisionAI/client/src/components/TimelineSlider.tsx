import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { ERAS } from "@/types";

const TIMELINE_INVENTIONS = {
  ancient: [
    { name: "Stone Tablet Phone", icon: "tablet-alt", description: "Carved stone communication tablets" },
    { name: "Pyramid Computer", icon: "monument", description: "Geometric calculation chambers" },
    { name: "Chariot Auto", icon: "horse", description: "Self-propelled ceremonial chariot" },
    { name: "Sun Calculator", icon: "sun", description: "Solar-powered counting device" },
  ],
  medieval: [
    { name: "Castle Telegraph", icon: "castle", description: "Tower-based message system" },
    { name: "Monastery Computer", icon: "cross", description: "Monk-operated calculation engine" },
    { name: "Guild Carriage", icon: "horse-head", description: "Craftsman's motorless wagon" },
    { name: "Windmill Engine", icon: "fan", description: "Wind-powered machinery" },
  ],
  renaissance: [
    { name: "Renaissance Camera", icon: "palette", description: "Camera obscura with artistic enhancements" },
    { name: "Mechanical Bicycle", icon: "bicycle", description: "Wooden frame with gear mechanisms" },
    { name: "Mechanical Piano", icon: "music", description: "Self-playing instrument with rotating drums" },
    { name: "Navigation Computer", icon: "globe", description: "Astrolabe with calculation wheels" },
  ],
  industrial: [
    { name: "Steam Telegraph", icon: "industry", description: "Steam-powered communication network" },
    { name: "Mechanical Calculator", icon: "calculator", description: "Gear-driven computation machine" },
    { name: "Steam Carriage", icon: "train", description: "Steam-powered personal transport" },
    { name: "Factory Engine", icon: "cogs", description: "Industrial automation system" },
  ],
  victorian: [
    { name: "Brass Telephone", icon: "phone", description: "Ornate brass communication device" },
    { name: "Difference Engine", icon: "desktop", description: "Babbage-style computation machine" },
    { name: "Steam Automobile", icon: "car", description: "Victorian steam-powered vehicle" },
    { name: "Electric Generator", icon: "bolt", description: "Early electrical power system" },
  ],
  early20th: [
    { name: "Radio Telephone", icon: "radio", description: "Early wireless communication" },
    { name: "Punch Card Computer", icon: "address-card", description: "Mechanical data processing" },
    { name: "Motor Car", icon: "car", description: "Internal combustion vehicle" },
    { name: "Power Plant", icon: "industry", description: "Electrical generation facility" },
  ],
};

export default function TimelineSlider() {
  const [selectedEra, setSelectedEra] = useState(2); // Renaissance by default

  const currentEra = ERAS[selectedEra];
  const currentInventions = TIMELINE_INVENTIONS[currentEra.id as keyof typeof TIMELINE_INVENTIONS] || [];

  return (
    <section className="py-16 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Historical Timeline Explorer</h2>
          <div className="ornate-divider mb-6 max-w-md mx-auto"></div>
          <p className="text-muted-foreground">Discover how inventions might have evolved across different historical periods</p>
        </div>

        <Card className="parchment-card vintage-border">
          <CardContent className="p-8">
            {/* Timeline Slider */}
            <div className="mb-8">
              <Slider
                value={[selectedEra]}
                onValueChange={(value) => setSelectedEra(value[0])}
                max={ERAS.length - 1}
                min={0}
                step={1}
                className="w-full mb-4"
                data-testid="timeline-slider"
              />
              <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-center">
                {ERAS.map((era, index) => (
                  <div 
                    key={era.id}
                    className={`timeline-era cursor-pointer ${index === selectedEra ? 'active' : ''}`}
                    onClick={() => setSelectedEra(index)}
                    data-testid={`timeline-era-${era.id}`}
                  >
                    <div className="text-xs font-semibold">{era.name}</div>
                    <div className="text-xs text-muted-foreground">{era.period}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Era-specific Inventions */}
            <div className="mb-6">
              <h3 className="font-serif text-xl font-semibold text-foreground mb-4 text-center">
                Possible Inventions in the {currentEra.name} Era
              </h3>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {currentInventions.map((invention, index) => (
                <Card 
                  key={`${currentEra.id}-${index}`}
                  className="border border-border hover:bg-accent/10 transition-colors cursor-pointer"
                  data-testid={`invention-card-${invention.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center mb-2">
                      <i className={`fas fa-${invention.icon} text-accent mr-2`}></i>
                      <span className="font-semibold text-sm">{invention.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{invention.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
