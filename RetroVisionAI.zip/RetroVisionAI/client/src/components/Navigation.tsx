import { Link } from "wouter";

export default function Navigation() {
  return (
    <nav className="vintage-border border-t-0 border-l-0 border-r-0 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3" data-testid="nav-home">
            <i className="fas fa-cogs text-2xl text-accent"></i>
            <span className="font-serif font-bold text-xl text-foreground">Retro-Vision AI</span>
          </Link>
          <div className="hidden md:flex items-center space-x-6">
            <a href="#explore" className="text-muted-foreground hover:text-accent transition-colors" data-testid="nav-explore">
              Explore
            </a>
            <a href="#examples" className="text-muted-foreground hover:text-accent transition-colors" data-testid="nav-examples">
              Examples
            </a>
            <a href="#about" className="text-muted-foreground hover:text-accent transition-colors" data-testid="nav-about">
              About
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
