export default function Footer() {
  return (
    <footer className="vintage-border border-b-0 border-l-0 border-r-0 bg-card py-8 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <div className="flex items-center justify-center space-x-3 mb-4">
          <i className="fas fa-cogs text-2xl text-accent"></i>
          <span className="font-serif font-bold text-xl text-foreground">Retro-Vision AI</span>
        </div>
        <p className="text-muted-foreground text-sm mb-4">
          Reimagining tomorrow's innovations with yesterday's wisdom
        </p>
        <div className="ornate-divider mb-4 max-w-md mx-auto"></div>
        <div className="flex justify-center space-x-6 text-sm">
          <a href="#" className="text-muted-foreground hover:text-accent transition-colors">Privacy</a>
          <a href="#" className="text-muted-foreground hover:text-accent transition-colors">Terms</a>
          <a href="#" className="text-muted-foreground hover:text-accent transition-colors">Contact</a>
          <a href="#" className="text-muted-foreground hover:text-accent transition-colors">GitHub</a>
        </div>
      </div>
    </footer>
  );
}
