import { apiRequest } from "./queryClient";
import { GenerateInventionRequest, ExportRequest, TranscribeAudioRequest } from "@shared/schema";

export const api = {
  generateInvention: async (data: GenerateInventionRequest) => {
    const response = await apiRequest("POST", "/api/generate", data);
    return response.json();
  },

  getInvention: async (id: string) => {
    const response = await apiRequest("GET", `/api/inventions/${id}`);
    return response.json();
  },

  getExamples: async () => {
    const response = await apiRequest("GET", "/api/examples");
    return response.json();
  },

  transcribeAudio: async (data: TranscribeAudioRequest) => {
    const response = await apiRequest("POST", "/api/transcribe", data);
    return response.json();
  },

  exportInvention: async (data: ExportRequest) => {
    const response = await apiRequest("POST", "/api/export", data);
    return response.blob();
  },

  health: async () => {
    const response = await apiRequest("GET", "/api/health");
    return response.json();
  },
};
