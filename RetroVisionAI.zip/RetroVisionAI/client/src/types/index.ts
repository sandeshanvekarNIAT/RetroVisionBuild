export interface Era {
  id: string;
  name: string;
  period: string;
  icon: string;
}

export interface InventionSuggestion {
  name: string;
  category: string;
}

export interface TimelineItem {
  step: number;
  title: string;
  description: string;
  period?: string;
}

export interface GenerationResult {
  invention: {
    id: string;
    name: string;
    era: string;
    creativity: number;
    dependencies: any;
    narrative: string;
    imageUrl?: string;
    timelineData: any;
    createdAt: Date;
  };
  eraDateRange: string;
}

export interface FeaturedExample {
  id: string;
  name: string;
  era: string;
  description: string;
  imageUrl?: string;
  featured: boolean;
}

export const ERAS: Era[] = [
  { id: "ancient", name: "Ancient", period: "3000 BC - 500 AD", icon: "monument" },
  { id: "medieval", name: "Medieval", period: "476 - 1453", icon: "chess-rook" },
  { id: "renaissance", name: "Renaissance", period: "1300 - 1600", icon: "palette" },
  { id: "industrial", name: "Industrial", period: "1760 - 1840", icon: "industry" },
  { id: "victorian", name: "Victorian", period: "1837 - 1901", icon: "hat-cowboy" },
  { id: "early20th", name: "Early 20th", period: "1900 - 1950", icon: "train" },
];

export const INVENTION_SUGGESTIONS: InventionSuggestion[] = [
  { name: "Smartphone", category: "Communication" },
  { name: "Laptop", category: "Computing" },
  { name: "Electric Car", category: "Transportation" },
  { name: "Solar Panel", category: "Energy" },
  { name: "Microwave", category: "Appliance" },
  { name: "GPS", category: "Navigation" },
  { name: "WiFi Router", category: "Communication" },
  { name: "Digital Camera", category: "Photography" },
];
