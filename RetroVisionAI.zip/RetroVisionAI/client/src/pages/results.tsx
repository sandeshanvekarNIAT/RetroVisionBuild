import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { api } from "@/lib/api";
import Navigation from "@/components/Navigation";
import ResultsView from "@/components/ResultsView";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";

export default function Results() {
  const { id } = useParams();

  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/inventions", id],
    queryFn: () => api.getInvention(id!),
    enabled: !!id,
  });

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="parchment-card vintage-border rounded-xl p-8">
            <i className="fas fa-exclamation-triangle text-destructive text-4xl mb-4"></i>
            <h1 className="font-serif text-2xl font-bold text-foreground mb-4">
              Failed to Load Results
            </h1>
            <p className="text-muted-foreground mb-6">
              We couldn't retrieve your invention results. Please try again.
            </p>
            <Link href="/">
              <Button className="steampunk-button text-primary-foreground" data-testid="button-back-home">
                <i className="fas fa-home mr-2"></i>
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {!isLoading && data && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          <Link href="/">
            <Button 
              variant="outline" 
              className="mb-6"
              data-testid="button-back-to-explore"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Explore
            </Button>
          </Link>
        </div>
      )}
      
      <ResultsView data={data} isLoading={isLoading} />
      
      <Footer />
    </div>
  );
}
