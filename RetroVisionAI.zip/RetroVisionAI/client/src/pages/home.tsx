import { useRef } from "react";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import FeaturedExamples from "@/components/FeaturedExamples";
import InputForm from "@/components/InputForm";
import TimelineSlider from "@/components/TimelineSlider";
import Footer from "@/components/Footer";

export default function Home() {
  const exploreRef = useRef<HTMLDivElement>(null);
  const examplesRef = useRef<HTMLDivElement>(null);

  const scrollToExplore = () => {
    exploreRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToExamples = () => {
    examplesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <HeroSection 
        onStartExploring={scrollToExplore}
        onViewExamples={scrollToExamples}
      />
      
      <div ref={examplesRef}>
        <FeaturedExamples />
      </div>
      
      <div ref={exploreRef}>
        <InputForm />
      </div>
      
      <TimelineSlider />
      
      {/* About Section */}
      <section id="about" className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-serif text-3xl font-bold text-foreground mb-6">About Retro-Vision AI</h2>
          <div className="ornate-divider mb-8 max-w-md mx-auto"></div>
          <p className="text-lg text-muted-foreground leading-relaxed mb-8">
            Retro-Vision AI combines cutting-edge artificial intelligence with historical knowledge to create fascinating alternate histories. 
            Our platform uses advanced language models to deconstruct modern inventions and reimagine them using the materials, 
            science, and cultural context of bygone eras.
          </p>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <i className="fas fa-brain text-accent text-3xl mb-4"></i>
              <h3 className="font-serif font-semibold mb-2">AI-Powered Analysis</h3>
              <p className="text-sm text-muted-foreground">Advanced language models analyze and deconstruct inventions</p>
            </div>
            <div className="text-center">
              <i className="fas fa-book text-accent text-3xl mb-4"></i>
              <h3 className="font-serif font-semibold mb-2">Historical Accuracy</h3>
              <p className="text-sm text-muted-foreground">Grounded in real historical materials and technologies</p>
            </div>
            <div className="text-center">
              <i className="fas fa-image text-accent text-3xl mb-4"></i>
              <h3 className="font-serif font-semibold mb-2">Visual Generation</h3>
              <p className="text-sm text-muted-foreground">Creates authentic historical blueprints and schematics</p>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
