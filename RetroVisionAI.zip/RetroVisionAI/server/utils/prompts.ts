export const DECONSTRUCTION_PROMPT = (invention: string, era: string) => `
Analyze the modern invention "${invention}" and break it down into its fundamental building blocks for the ${era} era.

Consider:
- Core materials and components needed
- Physical principles and energy sources available in that era
- Manufacturing techniques and tools of the time
- Cultural and social context that would drive its development

Provide a JSON response with:
{
  "materials": ["list of era-appropriate materials"],
  "energy": "power source available in that era",
  "manufacturing": "how it would be made with era tools",
  "dependencies": ["prerequisite technologies or knowledge"],
  "challenges": ["major obstacles to overcome"]
}

Be historically accurate but creative in finding era-appropriate alternatives.
`;

export const SIMULATION_PROMPT = (invention: string, era: string, creativity: number) => `
Imagine how "${invention}" might have been invented and developed during the ${era} era.

Creativity level: ${creativity}/10 (1=very realistic, 10=highly imaginative)

Create an alternate history scenario considering:
- Available materials and technology of the ${era} era
- Social and cultural context of the time
- How it would be used and by whom
- What it would be called in that era
- How it would evolve over time

Provide a detailed timeline showing:
1. Initial concept and early prototypes
2. Key developments and improvements
3. Social adoption and cultural impact

Make it engaging and plausible for the chosen era.
`;

export const NARRATIVE_PROMPT = (invention: string, era: string, timelineData: any) => `
Write a 250-350 word historical archive entry about the "${invention}" as if it really existed during the ${era} era.

Context: ${JSON.stringify(timelineData)}

Write in the style of a historical document from that period, including:
- Specific dates and historical figures (can be fictional but period-appropriate)
- Technical details using era-appropriate language
- Social and cultural impact of the invention
- How it was received by society and authorities

Make it sound authentic and scholarly, as if discovered in historical archives.
Format as a formal historical entry with proper attribution and dating.
`;

export const IMAGE_PROMPT = (invention: string, era: string, style: string = "blueprint") => {
  const eraStyles = {
    ancient: "ancient stone tablet carving, hieroglyphic style",
    medieval: "illuminated manuscript page, medieval parchment with decorative borders",
    renaissance: "Leonardo da Vinci style technical drawing, renaissance blueprint",
    industrial: "Victorian engineering blueprint, detailed technical schematic",
    victorian: "steampunk style blueprint, brass and copper aesthetic, Victorian era technical drawing",
    early20th: "early 1900s engineering drawing, art deco style technical diagram"
  };

  const basePrompt = `${eraStyles[era as keyof typeof eraStyles] || eraStyles.victorian} of a ${invention}, detailed technical diagram, parchment background, historical accuracy, sepia tones, ornate decorative elements, vintage aesthetic, high quality, detailed illustration`;
  
  return basePrompt;
};

export const getEraDateRange = (era: string): string => {
  const ranges = {
    ancient: "3000 BC - 500 AD",
    medieval: "476 - 1453",
    renaissance: "1300 - 1600",
    industrial: "1760 - 1840",
    victorian: "1837 - 1901",
    early20th: "1900 - 1950"
  };
  
  return ranges[era as keyof typeof ranges] || "Unknown era";
};
