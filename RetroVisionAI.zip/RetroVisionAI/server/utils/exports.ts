import { Invention } from "@shared/schema";
import * as puppeteer from "puppeteer";
import PptxGenJS from "pptxgenjs";
import { getEraDateRange } from "./prompts";

export class ExportService {
  async generatePDF(invention: Invention): Promise<Buffer> {
    let browser: puppeteer.Browser | null = null;
    
    try {
      const htmlContent = this.generateHTMLContent(invention);
      
      // Launch puppeteer browser with built-in timeout
      browser = await puppeteer.launch({
        headless: true,
        timeout: 30000, // 30 seconds timeout
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--disable-gpu'
        ]
      });
      
      const page = await browser.newPage();
      
      // Set the HTML content with built-in timeout
      await page.setContent(htmlContent, {
        waitUntil: ['networkidle0', 'domcontentloaded'],
        timeout: 30000 // 30 seconds timeout
      });
      
      // Generate PDF with proper options
      const pdfBuffer = await page.pdf({
        format: 'A4',
        margin: {
          top: '0.75in',
          right: '0.75in',
          bottom: '0.75in',
          left: '0.75in'
        },
        printBackground: true,
        preferCSSPageSize: true
      });
      
      return Buffer.from(pdfBuffer);
    } catch (error) {
      console.error('PDF generation failed:', error);
      throw new Error(`PDF generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      if (browser) {
        try {
          await browser.close();
        } catch (closeError) {
          console.error('Error closing browser:', closeError);
        }
      }
    }
  }

  private async fetchImageAsBase64(imageUrl: string): Promise<string | null> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
      
      const response = await fetch(imageUrl, { 
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        console.warn(`Failed to fetch image: ${response.status} ${response.statusText}`);
        return null;
      }
      
      const contentType = response.headers.get('content-type');
      if (!contentType?.startsWith('image/')) {
        console.warn(`Invalid content type for image: ${contentType}`);
        return null;
      }
      
      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const base64 = buffer.toString('base64');
      
      return `data:${contentType};base64,${base64}`;
    } catch (error) {
      console.warn('Failed to fetch image as base64:', error);
      return null;
    }
  }

  async generatePPTX(invention: Invention): Promise<Buffer> {
    try {
      const pres = new PptxGenJS();
      const eraDateRange = getEraDateRange(invention.era);
      
      // Set presentation properties
      pres.layout = 'LAYOUT_16x9';
      pres.title = `Historical Dossier: ${invention.name}`;
      
      // Historical color scheme
      const colors = {
        primary: '#8B4513',      // saddle brown
        accent: '#DAA520',       // goldenrod
        background: '#FFF8DC',   // cornsilk
        text: '#2F2F2F',         // dark gray
        border: '#CD853F'        // peru
      };

      // Slide 1: Title Slide
      const titleSlide = pres.addSlide();
      titleSlide.background = { color: colors.background };
      
      titleSlide.addText('HISTORICAL DOSSIER', {
        x: 1, y: 1.5, w: 8, h: 1,
        fontSize: 44, bold: true, color: colors.primary,
        align: 'center', fontFace: 'Playfair Display'
      });
      
      titleSlide.addText(invention.name, {
        x: 1, y: 2.8, w: 8, h: 1.2,
        fontSize: 36, bold: true, color: colors.accent,
        align: 'center', fontFace: 'Playfair Display'
      });
      
      titleSlide.addText(`${invention.era.toUpperCase()} ERA (${eraDateRange})`, {
        x: 1, y: 4.2, w: 8, h: 0.8,
        fontSize: 24, color: colors.text,
        align: 'center', fontFace: 'Inter'
      });
      
      titleSlide.addText(`Generated: ${invention.createdAt?.toLocaleDateString() || 'Unknown Date'}`, {
        x: 1, y: 5.5, w: 8, h: 0.5,
        fontSize: 16, color: colors.text,
        align: 'center', fontFace: 'Inter'
      });

      // Slide 2: Dependencies Overview
      if (invention.dependencies) {
        const depsSlide = pres.addSlide();
        depsSlide.background = { color: colors.background };
        
        depsSlide.addText('DEPENDENCIES & MATERIALS', {
          x: 0.5, y: 0.5, w: 9, h: 0.8,
          fontSize: 32, bold: true, color: colors.primary,
          align: 'center', fontFace: 'Playfair Display'
        });
        
        const deps = invention.dependencies as any;
        let yPos = 1.8;
        
        if (deps.materials) {
          depsSlide.addText('Materials:', {
            x: 1, y: yPos, w: 8, h: 0.4,
            fontSize: 18, bold: true, color: colors.accent, fontFace: 'Inter'
          });
          depsSlide.addText(Array.isArray(deps.materials) ? deps.materials.join(', ') : deps.materials, {
            x: 1.5, y: yPos + 0.4, w: 7, h: 0.6,
            fontSize: 14, color: colors.text, fontFace: 'Inter'
          });
          yPos += 1.2;
        }
        
        if (deps.energy) {
          depsSlide.addText('Energy Source:', {
            x: 1, y: yPos, w: 8, h: 0.4,
            fontSize: 18, bold: true, color: colors.accent, fontFace: 'Inter'
          });
          depsSlide.addText(deps.energy, {
            x: 1.5, y: yPos + 0.4, w: 7, h: 0.6,
            fontSize: 14, color: colors.text, fontFace: 'Inter'
          });
          yPos += 1.2;
        }
        
        if (deps.manufacturing) {
          depsSlide.addText('Manufacturing:', {
            x: 1, y: yPos, w: 8, h: 0.4,
            fontSize: 18, bold: true, color: colors.accent, fontFace: 'Inter'
          });
          depsSlide.addText(deps.manufacturing, {
            x: 1.5, y: yPos + 0.4, w: 7, h: 0.6,
            fontSize: 14, color: colors.text, fontFace: 'Inter'
          });
        }
      }

      // Slide 3: Timeline Simulation
      if (invention.timelineData) {
        const timelineSlide = pres.addSlide();
        timelineSlide.background = { color: colors.background };
        
        timelineSlide.addText('HISTORICAL SIMULATION', {
          x: 0.5, y: 0.5, w: 9, h: 0.8,
          fontSize: 32, bold: true, color: colors.primary,
          align: 'center', fontFace: 'Playfair Display'
        });
        
        const timeline = invention.timelineData as any;
        if (timeline.simulation) {
          timelineSlide.addText(timeline.simulation, {
            x: 1, y: 1.8, w: 8, h: 4,
            fontSize: 14, color: colors.text,
            align: 'left', fontFace: 'Inter',
            wrap: true
          });
        }
      }

      // Slide 4: Historical Narrative
      if (invention.narrative) {
        const narrativeSlide = pres.addSlide();
        narrativeSlide.background = { color: colors.background };
        
        narrativeSlide.addText('HISTORICAL NARRATIVE', {
          x: 0.5, y: 0.5, w: 9, h: 0.8,
          fontSize: 32, bold: true, color: colors.primary,
          align: 'center', fontFace: 'Playfair Display'
        });
        
        narrativeSlide.addText(invention.narrative, {
          x: 1, y: 1.8, w: 8, h: 4,
          fontSize: 14, color: colors.text,
          align: 'left', fontFace: 'Inter',
          wrap: true
        });
      }

      // Slide 5: Prototype Images (if available)
      if (invention.imageUrl) {
        const imageSlide = pres.addSlide();
        imageSlide.background = { color: colors.background };
        
        imageSlide.addText('PROTOTYPE DESIGN', {
          x: 0.5, y: 0.5, w: 9, h: 0.8,
          fontSize: 32, bold: true, color: colors.primary,
          align: 'center', fontFace: 'Playfair Display'
        });
        
        // Fetch remote image as base64
        const imageBase64 = await this.fetchImageAsBase64(invention.imageUrl);
        
        if (imageBase64) {
          try {
            imageSlide.addImage({
              data: imageBase64,
              x: 2, y: 2, w: 6, h: 4
            });
          } catch (error) {
            console.error('Failed to add base64 image to slide:', error);
            imageSlide.addText('Image could not be processed', {
              x: 2, y: 4, w: 6, h: 1,
              fontSize: 16, color: colors.text,
              align: 'center', fontFace: 'Inter'
            });
          }
        } else {
          imageSlide.addText('Image could not be loaded', {
            x: 2, y: 4, w: 6, h: 1,
            fontSize: 16, color: colors.text,
            align: 'center', fontFace: 'Inter'
          });
        }
      }

      // Generate and return PPTX buffer using proper method
      const pptxBuffer = await pres.write({ outputType: 'nodebuffer' }) as Buffer;
      return pptxBuffer;
    } catch (error) {
      console.error('PPTX generation failed:', error);
      
      // Create minimal valid PPTX as fallback
      try {
        const fallbackPres = new PptxGenJS();
        fallbackPres.layout = 'LAYOUT_16x9';
        
        const fallbackSlide = fallbackPres.addSlide();
        fallbackSlide.addText('HISTORICAL DOSSIER', {
          x: 1, y: 2, w: 8, h: 1,
          fontSize: 36, bold: true, color: '8B4513',
          align: 'center'
        });
        fallbackSlide.addText(invention.name, {
          x: 1, y: 3.5, w: 8, h: 1,
          fontSize: 24, color: 'DAA520',
          align: 'center'
        });
        fallbackSlide.addText('Export error occurred. Please try again.', {
          x: 1, y: 5, w: 8, h: 0.5,
          fontSize: 16, color: '666666',
          align: 'center'
        });
        
        const fallbackBuffer = await fallbackPres.write({ outputType: 'nodebuffer' }) as Buffer;
        return fallbackBuffer;
      } catch (fallbackError) {
        console.error('Fallback PPTX generation also failed:', fallbackError);
        throw new Error(`PPTX generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }
  }

  private generateHTMLContent(invention: Invention): string {
    const eraDateRange = getEraDateRange(invention.era);
    const deps = invention.dependencies as any || {};
    const timeline = invention.timelineData as any || {};
    
    return `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Historical Dossier: ${invention.name}</title>
          <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
          <style>
            @page {
              size: A4;
              margin: 0.75in;
              background: linear-gradient(135deg, #FFF8DC 0%, #F5F5DC 50%, #F0E68C 100%);
            }
            
            * {
              box-sizing: border-box;
            }
            
            body {
              font-family: 'Inter', 'Times New Roman', serif;
              line-height: 1.6;
              color: #2F2F2F;
              background: linear-gradient(135deg, #FFF8DC 0%, #F5F5DC 50%, #F0E68C 100%);
              margin: 0;
              padding: 20px;
              background-attachment: fixed;
            }
            
            .document-container {
              max-width: 100%;
              background: rgba(255, 248, 220, 0.95);
              border: 3px solid #8B4513;
              border-radius: 10px;
              box-shadow: 
                0 0 20px rgba(139, 69, 19, 0.3),
                inset 0 0 0 2px #DAA520;
              position: relative;
              overflow: hidden;
            }
            
            .document-container::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
              background: 
                radial-gradient(circle at 20% 30%, rgba(218, 165, 32, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(139, 69, 19, 0.1) 0%, transparent 50%);
              pointer-events: none;
            }
            
            .content {
              position: relative;
              z-index: 1;
              padding: 40px;
            }
            
            .header {
              text-align: center;
              border-bottom: 3px double #8B4513;
              margin-bottom: 40px;
              padding-bottom: 30px;
              position: relative;
            }
            
            .header::after {
              content: '❋ ❋ ❋';
              position: absolute;
              bottom: -12px;
              left: 50%;
              transform: translateX(-50%);
              background: #FFF8DC;
              color: #DAA520;
              padding: 0 15px;
              font-size: 16px;
            }
            
            .title-main {
              font-family: 'Playfair Display', serif;
              font-size: 42px;
              font-weight: 700;
              color: #8B4513;
              margin: 0 0 15px 0;
              text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
              letter-spacing: 2px;
            }
            
            .title-sub {
              font-family: 'Playfair Display', serif;
              font-size: 28px;
              font-weight: 600;
              color: #DAA520;
              margin: 0 0 10px 0;
              font-style: italic;
            }
            
            .era-info {
              font-size: 18px;
              color: #8B4513;
              margin: 5px 0;
              font-weight: 500;
            }
            
            .date-info {
              font-size: 14px;
              color: #666;
              margin-top: 15px;
              font-style: italic;
            }
            
            .section {
              margin-bottom: 35px;
              position: relative;
            }
            
            .section-title {
              font-family: 'Playfair Display', serif;
              font-size: 24px;
              font-weight: 600;
              color: #8B4513;
              margin-bottom: 20px;
              padding-bottom: 10px;
              border-bottom: 2px solid #DAA520;
              position: relative;
            }
            
            .section-title::after {
              content: '§';
              position: absolute;
              right: 0;
              bottom: -8px;
              background: #FFF8DC;
              color: #DAA520;
              padding: 0 8px;
              font-size: 18px;
            }
            
            .narrative-box {
              background: linear-gradient(135deg, #FFF8DC 0%, #F5F5DC 100%);
              border: 2px solid #DAA520;
              border-radius: 8px;
              padding: 25px;
              box-shadow: 
                inset 0 1px 3px rgba(0,0,0,0.1),
                0 2px 8px rgba(139, 69, 19, 0.2);
              position: relative;
              font-size: 16px;
              line-height: 1.8;
            }
            
            .narrative-box::before {
              content: '"';
              position: absolute;
              top: -10px;
              left: 20px;
              font-size: 48px;
              color: #DAA520;
              font-family: 'Playfair Display', serif;
            }
            
            .deps-grid {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
              gap: 20px;
              margin-top: 15px;
            }
            
            .dep-item {
              background: rgba(255, 255, 255, 0.8);
              border: 1px solid #DAA520;
              border-radius: 6px;
              padding: 15px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .dep-label {
              font-weight: 600;
              color: #8B4513;
              font-size: 14px;
              text-transform: uppercase;
              letter-spacing: 1px;
              margin-bottom: 8px;
              font-family: 'Playfair Display', serif;
            }
            
            .dep-content {
              color: #2F2F2F;
              font-size: 14px;
              line-height: 1.5;
            }
            
            .dep-list {
              list-style: none;
              padding: 0;
              margin: 0;
            }
            
            .dep-list li {
              padding: 3px 0;
              position: relative;
              padding-left: 20px;
            }
            
            .dep-list li::before {
              content: '⚡';
              position: absolute;
              left: 0;
              color: #DAA520;
            }
            
            .timeline-content {
              background: rgba(255, 255, 255, 0.9);
              border: 2px solid #8B4513;
              border-radius: 8px;
              padding: 20px;
              font-size: 15px;
              line-height: 1.7;
              white-space: pre-line;
              box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            }
            
            .image-section {
              text-align: center;
              margin: 30px 0;
            }
            
            .prototype-image {
              max-width: 100%;
              height: auto;
              border: 3px solid #8B4513;
              border-radius: 8px;
              box-shadow: 0 4px 12px rgba(0,0,0,0.2);
              background: white;
              padding: 10px;
            }
            
            .image-caption {
              font-style: italic;
              color: #666;
              margin-top: 10px;
              font-size: 14px;
            }
            
            .footer {
              margin-top: 50px;
              text-align: center;
              border-top: 2px solid #DAA520;
              padding-top: 20px;
              font-size: 12px;
              color: #666;
            }
            
            @media print {
              .document-container {
                border: none;
                box-shadow: none;
              }
              
              body {
                background: white !important;
              }
              
              .content {
                padding: 20px;
              }
            }
          </style>
        </head>
        <body>
          <div class="document-container">
            <div class="content">
              <header class="header">
                <h1 class="title-main">HISTORICAL DOSSIER</h1>
                <h2 class="title-sub">${invention.name}</h2>
                <div class="era-info">${invention.era.toUpperCase()} ERA (${eraDateRange})</div>
                <div class="date-info">Document Generated: ${invention.createdAt?.toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                }) || 'Unknown Date'}</div>
              </header>
              
              ${invention.narrative ? `
              <section class="section">
                <h3 class="section-title">Historical Narrative</h3>
                <div class="narrative-box">
                  ${invention.narrative}
                </div>
              </section>
              ` : ''}
              
              ${deps && Object.keys(deps).length > 0 ? `
              <section class="section">
                <h3 class="section-title">Dependencies & Materials</h3>
                <div class="deps-grid">
                  ${deps.materials ? `
                  <div class="dep-item">
                    <div class="dep-label">Materials</div>
                    <div class="dep-content">
                      ${Array.isArray(deps.materials) ? 
                        `<ul class="dep-list">${deps.materials.map((m: string) => `<li>${m}</li>`).join('')}</ul>` : 
                        deps.materials
                      }
                    </div>
                  </div>
                  ` : ''}
                  
                  ${deps.energy ? `
                  <div class="dep-item">
                    <div class="dep-label">Energy Source</div>
                    <div class="dep-content">${deps.energy}</div>
                  </div>
                  ` : ''}
                  
                  ${deps.manufacturing ? `
                  <div class="dep-item">
                    <div class="dep-label">Manufacturing</div>
                    <div class="dep-content">${deps.manufacturing}</div>
                  </div>
                  ` : ''}
                  
                  ${deps.dependencies ? `
                  <div class="dep-item">
                    <div class="dep-label">Prerequisites</div>
                    <div class="dep-content">
                      ${Array.isArray(deps.dependencies) ? 
                        `<ul class="dep-list">${deps.dependencies.map((d: string) => `<li>${d}</li>`).join('')}</ul>` : 
                        deps.dependencies
                      }
                    </div>
                  </div>
                  ` : ''}
                  
                  ${deps.challenges ? `
                  <div class="dep-item">
                    <div class="dep-label">Challenges</div>
                    <div class="dep-content">
                      ${Array.isArray(deps.challenges) ? 
                        `<ul class="dep-list">${deps.challenges.map((c: string) => `<li>${c}</li>`).join('')}</ul>` : 
                        deps.challenges
                      }
                    </div>
                  </div>
                  ` : ''}
                </div>
              </section>
              ` : ''}
              
              ${timeline.simulation ? `
              <section class="section">
                <h3 class="section-title">Historical Simulation</h3>
                <div class="timeline-content">${timeline.simulation}</div>
              </section>
              ` : ''}
              
              ${invention.imageUrl ? `
              <section class="section">
                <h3 class="section-title">Prototype Design</h3>
                <div class="image-section">
                  <img src="${invention.imageUrl}" alt="Prototype design for ${invention.name}" class="prototype-image" />
                  <div class="image-caption">Historical reconstruction of ${invention.name} design</div>
                </div>
              </section>
              ` : ''}
              
              <footer class="footer">
                <div>Historical dossier compiled through advanced temporal analysis</div>
                <div>Creativity Index: ${invention.creativity}/10 | Era Authenticity Verified</div>
              </footer>
            </div>
          </div>
        </body>
      </html>
    `;
  }
}

export const exportService = new ExportService();
