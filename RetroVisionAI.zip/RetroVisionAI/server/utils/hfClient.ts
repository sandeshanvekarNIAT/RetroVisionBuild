import { HfInference } from '@huggingface/inference';

export class HuggingFaceClient {
  private apiKey: string;
  private hf: HfInference;

  constructor() {
    this.apiKey = process.env.HF_API_KEY || process.env.HUGGING_FACE_API_KEY || "";
    if (!this.apiKey) {
      console.warn("No Hugging Face API key found. AI features will not work.");
    }
    this.hf = new HfInference(this.apiKey);
  }


  async generateText(model: string, prompt: string, maxTokens = 500): Promise<string> {
    try {
      if (!this.apiKey) {
        throw new Error("Hugging Face API key not configured");
      }

      // Use chat completion format for newer models
      const response = await this.hf.chatCompletion({
        model: model,
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens,
        temperature: 0.7,
      });

      if (response?.choices?.[0]?.message?.content) {
        return response.choices[0].message.content.trim();
      }
      
      throw new Error("Invalid response format from text generation API");
    } catch (error) {
      console.error("Text generation error:", error);
      // Fallback to text generation if chat completion fails
      try {
        const textResponse = await this.hf.textGeneration({
          model: model,
          inputs: prompt,
          parameters: {
            max_new_tokens: maxTokens,
            temperature: 0.7,
            return_full_text: false,
          },
        });
        return textResponse.generated_text?.trim() || "";
      } catch (fallbackError) {
        console.error("Fallback text generation error:", fallbackError);
        throw error;
      }
    }
  }

  async generateImage(prompt: string): Promise<string> {
    try {
      if (!this.apiKey) {
        throw new Error("Hugging Face API key not configured");
      }

      const blob = await this.hf.textToImage({
        model: "stabilityai/stable-diffusion-2-1",
        inputs: prompt,
        parameters: {
          num_inference_steps: 30,
          guidance_scale: 7.5,
        },
      });

      const buffer = await blob.arrayBuffer();
      const base64 = Buffer.from(buffer).toString('base64');
      return `data:image/png;base64,${base64}`;
    } catch (error) {
      console.error("Image generation error:", error);
      throw error;
    }
  }

  async transcribeAudio(audioBase64: string): Promise<string> {
    try {
      if (!this.apiKey) {
        throw new Error("Hugging Face API key not configured");
      }

      // Convert base64 to buffer
      const audioBuffer = Buffer.from(audioBase64, 'base64');
      
      const response = await this.hf.automaticSpeechRecognition({
        model: "openai/whisper-small",
        data: audioBuffer,
      });

      return response.text || "";
    } catch (error) {
      console.error("Audio transcription error:", error);
      throw error;
    }
  }
}

export const hfClient = new HuggingFaceClient();
