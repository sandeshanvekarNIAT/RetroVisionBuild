import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { hfClient } from "./utils/hfClient";
import { 
  DECONSTRUCTION_PROMPT, 
  SIMULATION_PROMPT, 
  NARRATIVE_PROMPT, 
  IMAGE_PROMPT,
  getEraDateRange 
} from "./utils/prompts";
import { exportService } from "./utils/exports";
import { 
  generateInventionSchema,
  transcribeAudioSchema,
  exportSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Get featured examples
  app.get("/api/examples", async (_req, res) => {
    try {
      const examples = await storage.getFeaturedExamples();
      res.json(examples);
    } catch (error) {
      console.error("Error fetching examples:", error);
      res.status(500).json({ message: "Failed to fetch examples" });
    }
  });

  // Generate invention
  app.post("/api/generate", async (req, res) => {
    try {
      const validatedData = generateInventionSchema.parse(req.body);
      const { invention, era, creativity } = validatedData;

      console.log(`Generating invention: ${invention} for ${era} era with creativity ${creativity}`);

      // Step 1: Deconstruct the invention
      const deconstructionPrompt = DECONSTRUCTION_PROMPT(invention, era);
      const deconstructionText = await hfClient.generateText(
        "mistralai/Mistral-7B-Instruct-v0.2",
        deconstructionPrompt,
        300
      );

      let dependencies;
      try {
        dependencies = JSON.parse(deconstructionText);
      } catch {
        // Fallback if JSON parsing fails
        dependencies = {
          materials: ["Era-appropriate materials"],
          energy: "Historical power source",
          manufacturing: "Traditional craftsmanship",
          dependencies: ["Basic tools and knowledge"],
          challenges: ["Technical limitations of the era"]
        };
      }

      // Step 2: Generate historical simulation
      const simulationPrompt = SIMULATION_PROMPT(invention, era, creativity);
      const simulationText = await hfClient.generateText(
        "meta-llama/Meta-Llama-3-8B-Instruct",
        simulationPrompt,
        400
      );

      // Step 3: Create narrative
      const narrativePrompt = NARRATIVE_PROMPT(invention, era, { simulation: simulationText });
      const narrative = await hfClient.generateText(
        "mistralai/Mistral-7B-Instruct-v0.2",
        narrativePrompt,
        350
      );

      // Step 4: Generate image
      const imagePrompt = IMAGE_PROMPT(invention, era);
      let imageUrl;
      try {
        imageUrl = await hfClient.generateImage(imagePrompt);
      } catch (error) {
        console.error("Image generation failed:", error);
        imageUrl = null;
      }

      // Step 5: Save to storage
      const savedInvention = await storage.createInvention({
        name: invention,
        era,
        creativity,
        dependencies,
        narrative,
        imageUrl,
        timelineData: { simulation: simulationText },
      });

      res.json({
        invention: savedInvention,
        eraDateRange: getEraDateRange(era),
      });

    } catch (error) {
      console.error("Error generating invention:", error);
      res.status(500).json({ 
        message: "Failed to generate invention",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get invention by ID
  app.get("/api/inventions/:id", async (req, res) => {
    try {
      const invention = await storage.getInvention(req.params.id);
      if (!invention) {
        return res.status(404).json({ message: "Invention not found" });
      }
      res.json({
        invention,
        eraDateRange: getEraDateRange(invention.era),
      });
    } catch (error) {
      console.error("Error fetching invention:", error);
      res.status(500).json({ message: "Failed to fetch invention" });
    }
  });

  // Transcribe audio
  app.post("/api/transcribe", async (req, res) => {
    try {
      const { audio } = transcribeAudioSchema.parse(req.body);
      const transcription = await hfClient.transcribeAudio(audio);
      res.json({ transcription });
    } catch (error) {
      console.error("Error transcribing audio:", error);
      res.status(500).json({ 
        message: "Failed to transcribe audio",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Export invention
  app.post("/api/export", async (req, res) => {
    try {
      const { inventionId, format } = exportSchema.parse(req.body);
      
      const invention = await storage.getInvention(inventionId);
      if (!invention) {
        return res.status(404).json({ message: "Invention not found" });
      }

      let buffer: Buffer;
      let contentType: string;
      let filename: string;

      if (format === "pdf") {
        buffer = await exportService.generatePDF(invention);
        contentType = "application/pdf";
        filename = `${invention.name.replace(/\s+/g, '_')}_dossier.pdf`;
      } else {
        buffer = await exportService.generatePPTX(invention);
        contentType = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        filename = `${invention.name.replace(/\s+/g, '_')}_presentation.pptx`;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(buffer);

    } catch (error) {
      console.error("Error exporting invention:", error);
      res.status(500).json({ 
        message: "Failed to export invention",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
