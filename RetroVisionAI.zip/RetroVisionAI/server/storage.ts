import { type Invention, type InsertInvention, type Example, type InsertExample, inventions, examples } from "@shared/schema";
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { eq, sql } from 'drizzle-orm';

export interface IStorage {
  getInvention(id: string): Promise<Invention | undefined>;
  createInvention(invention: InsertInvention): Promise<Invention>;
  getExamples(): Promise<Example[]>;
  getFeaturedExamples(): Promise<Example[]>;
  createExample(example: InsertExample): Promise<Example>;
}

// Database connection setup
const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error('DATABASE_URL is required');
}

const client = postgres(connectionString);
const db = drizzle(client);

// Ensure UUID extension is available
const initializeDatabase = async () => {
  try {
    await client`CREATE EXTENSION IF NOT EXISTS "pgcrypto"`;
  } catch (error) {
    console.warn('Could not create pgcrypto extension (may already exist):', error);
  }
};

// Initialize database on startup
initializeDatabase().catch(error => 
  console.error('Database initialization failed:', error)
);

export class DrizzleStorage implements IStorage {
  private seedingPromise: Promise<void> | null = null;

  constructor() {
    // Start seeding but don't block constructor
    this.seedingPromise = this.initializeExamples();
  }

  private async initializeExamples(): Promise<void> {
    try {
      const featuredExamples: InsertExample[] = [
        {
          name: "Victorian Smartphone",
          era: "victorian",
          description: "A brass-encased communication device powered by steam engines, featuring morse code messaging and mechanical computation wheels.",
          imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
          featured: true,
        },
        {
          name: "Medieval Computer",
          era: "medieval",
          description: "An elaborate wooden calculating machine with brass gears, operated by monks and used for astronomical calculations and record keeping.",
          imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
          featured: true,
        },
        {
          name: "Renaissance Automobile",
          era: "renaissance",
          description: "A horse-less carriage powered by intricate clockwork mechanisms and wind sails, designed by the era's finest engineers and artists.",
          imageUrl: "https://pixabay.com/get/g740f00c5e2f91e767c7e35487aa04d719b2937ebcf7260b820f0e75bf96ff080e078a0d7aa9f7d27907a12bb22dc30d72b283347cc72e2c79496144f5adc381c_1280.jpg",
          featured: true,
        },
      ];

      // Use upsert logic to prevent duplicates - idempotent seeding
      for (const example of featuredExamples) {
        await db.insert(examples)
          .values(example)
          .onConflictDoNothing({ target: [examples.name, examples.era] });
      }
    } catch (error) {
      console.error('Error initializing examples:', error);
      throw error; // Rethrow to ensure seeding failures are visible
    }
  }

  async getInvention(id: string): Promise<Invention | undefined> {
    // Let database errors propagate to routes for proper 500 responses
    const result = await db.select().from(inventions).where(eq(inventions.id, id)).limit(1);
    return result[0];
  }

  async createInvention(insertInvention: InsertInvention): Promise<Invention> {
    try {
      const result = await db.insert(inventions).values(insertInvention).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating invention:', error);
      throw error;
    }
  }

  async getExamples(): Promise<Example[]> {
    // Ensure seeding is complete before fetching
    if (this.seedingPromise) {
      await this.seedingPromise;
    }
    // Let database errors propagate to routes for proper 500 responses
    const result = await db.select().from(examples);
    return result;
  }

  async getFeaturedExamples(): Promise<Example[]> {
    // Ensure seeding is complete before fetching
    if (this.seedingPromise) {
      await this.seedingPromise;
    }
    // Let database errors propagate to routes for proper 500 responses
    const result = await db.select().from(examples).where(eq(examples.featured, true));
    return result;
  }

  async createExample(insertExample: InsertExample): Promise<Example> {
    const result = await db.insert(examples).values(insertExample).returning();
    return result[0];
  }
}

export const storage = new DrizzleStorage();
