# Retro-Vision AI

## Overview

Retro-Vision AI is a web application that lets users reimagine modern inventions in alternate historical eras. Users can input an invention (e.g., "Smartphone") and select a historical time period (e.g., "Victorian Era"), and the app uses AI models to deconstruct the invention into its fundamental building blocks, simulate alternate invention pathways using only the tools and science of that era, generate visual mockups with historical styling, and create narrative history entries as if the invention existed in that time period.

The application serves educational purposes for history and innovation classrooms, museums for interactive exhibits, creative ideation for authors and filmmakers, and curiosity-driven exploration of "what-if" scenarios.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built with React and TypeScript using Vite as the build tool. The UI follows a vintage/historical design theme with custom CSS styling for steampunk and parchment aesthetics. The application uses Wouter for client-side routing and TanStack Query for server state management. The component library is based on shadcn/ui with Radix UI primitives, providing a comprehensive set of accessible UI components styled with Tailwind CSS.

### Backend Architecture
The server is built with Express.js and TypeScript, following a RESTful API design. The application uses a modular architecture with separate route handlers, storage layer abstraction, and utility services. The server includes middleware for request logging, error handling, and development-specific Vite integration for hot module replacement.

### Data Storage
The application uses Drizzle ORM with PostgreSQL as the database. The schema includes tables for inventions (storing user-generated content) and examples (featured pre-made content). The storage layer uses an interface-based design allowing for multiple implementations, currently supporting both in-memory storage for development and PostgreSQL for production.

### AI Integration
The system integrates with Hugging Face's Inference API for text generation and image generation capabilities. The AI workflow consists of three main steps: deconstruction (breaking down modern inventions into fundamental components), simulation (reimagining how the invention might have developed in a historical era), and narrative generation (creating historical documentation). Each step uses carefully crafted prompts designed to maintain historical accuracy while encouraging creativity.

### Form Handling and Validation
The application uses React Hook Form with Zod schema validation for type-safe form handling. This ensures data integrity from the client through to the database layer, with shared schema definitions between frontend and backend.

### File Export System
The application includes an export service that generates PDF and PowerPoint presentations of the generated inventions, allowing users to download "historical dossiers" of their creations. The export system is designed to be extensible for additional formats.

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: TypeScript-first ORM for database operations
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### AI Services
- **Hugging Face Inference API**: Provides text generation capabilities using models like Mistral-7B-Instruct for creating historical narratives and invention deconstructions
- **Hugging Face Hub**: Access to diffusion models for generating historical-style images and visual mockups

### UI and Styling
- **Radix UI**: Unstyled, accessible UI primitives for building the component library
- **shadcn/ui**: Pre-built component library built on top of Radix UI
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography

### Development and Build Tools
- **Vite**: Fast build tool and development server with TypeScript support
- **Replit Plugins**: Development environment integration including error overlay, cartographer, and dev banner

### Audio Processing
- **Web Audio API**: Browser-native audio recording capabilities for voice input features

### Validation and Type Safety
- **Zod**: TypeScript-first schema validation library used across client and server
- **drizzle-zod**: Integration between Drizzle ORM and Zod for database schema validation