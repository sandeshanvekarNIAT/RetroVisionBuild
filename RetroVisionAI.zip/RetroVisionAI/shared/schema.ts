import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer, boolean, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const inventions = pgTable("inventions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  era: text("era").notNull(),
  creativity: integer("creativity").notNull(),
  dependencies: jsonb("dependencies"),
  narrative: text("narrative"),
  imageUrl: text("image_url"),
  timelineData: jsonb("timeline_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const examples = pgTable("examples", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  era: text("era").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  featured: boolean("featured").default(false),
}, (table) => ({
  // Unique constraint to prevent duplicate examples
  nameEraIdx: uniqueIndex("examples_name_era_idx").on(table.name, table.era),
}));

export const insertInventionSchema = createInsertSchema(inventions).omit({
  id: true,
  createdAt: true,
});

export const insertExampleSchema = createInsertSchema(examples).omit({
  id: true,
});

export type InsertInvention = z.infer<typeof insertInventionSchema>;
export type Invention = typeof inventions.$inferSelect;
export type InsertExample = z.infer<typeof insertExampleSchema>;
export type Example = typeof examples.$inferSelect;

// Request/Response schemas
export const generateInventionSchema = z.object({
  invention: z.string().min(1, "Invention name is required"),
  era: z.enum(["ancient", "medieval", "renaissance", "industrial", "victorian", "early20th"]),
  creativity: z.number().min(1).max(10),
});

export const transcribeAudioSchema = z.object({
  audio: z.string(), // base64 encoded audio
});

export const exportSchema = z.object({
  inventionId: z.string(),
  format: z.enum(["pdf", "pptx"]),
});

export type GenerateInventionRequest = z.infer<typeof generateInventionSchema>;
export type TranscribeAudioRequest = z.infer<typeof transcribeAudioSchema>;
export type ExportRequest = z.infer<typeof exportSchema>;
